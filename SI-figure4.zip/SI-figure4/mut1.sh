inpdb=$1
outpdb=$2
python /scratch/xc25/mut.py $inpdb x.pdb LEU PRO 115
python /scratch/xc25/mut.py x.pdb x1.pdb LEU PRO 483
python /scratch/xc25/mut.py x1.pdb x2.pdb LYS ARG 122
python /scratch/xc25/mut.py x2.pdb $outpdb LYS ARG 490

