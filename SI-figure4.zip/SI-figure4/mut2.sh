inpdb=$1
outpdb=$2
python /scratch/xc25/mut.py $inpdb.pdb x3.pdb LYS ARG 486
python /scratch/xc25/mut.py x3.pdb $outpdb LYS ARG 118
