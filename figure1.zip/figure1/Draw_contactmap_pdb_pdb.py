import numpy as np
import pandas
import prody
import matplotlib.pyplot as plt
from matplotlib.pyplot import cm as cm
import sys
import math
import os
np.set_printoptions(threshold=np.nan)


def vector(p1, p2):
    return [p2[0]-p1[0], p2[1]-p1[1], p2[2]-p1[2]]

def vabs(a):
    return math.sqrt(pow(a[0],2)+pow(a[1],2)+pow(a[2],2))
def checkIfNative(xyz_CAi, xyz_CAj):
    v = vector(xyz_CAi, xyz_CAj)
    r = vabs(v)
    if r<12.0: return True
    else: return False

def isNative(r):
        if r<12.0: return True
        else: return False

def get_ca_s_atoms(pdb_part):
    ca_atoms = []
    for line in pdb_part:
        if line.split()[0] != 'END':
           if line.split()[2] == 'CA' or line.split()[2] == 'S':
           #print line
              x=float(line[30:38])
              y=float(line[38:46])
              z=float(line[46:54])
              atom = [x,y,z]
              ca_atoms.append(atom)
   # print coord
    return ca_atoms

def compute_contactmap(ca_atoms):
    width = len(ca_atoms)
    contactmap = np.zeros((width,width))
    for i in range(width):
        for j in range(i+3,width):
            if checkIfNative(ca_atoms[i], ca_atoms[j]):
               contactmap[i][j] = 1.0
               contactmap[j][i] = contactmap[i][j]
    #print  np.max(contactmap)
    return contactmap

def merge_matrix(contactmap1,contactmap2,n_atoms):
    matrix = np.zeros((n_atoms,n_atoms))
    for i in range(n_atoms):
        for j in range(i+1,n_atoms):
            matrix[i][j] = contactmap1[i][j]
            matrix[j][i] = contactmap2[j][i]
    return matrix






def draw_contactmap(matrix,xname,yname,title):
    (n_atomsx,n_atomsy) = np.shape(matrix)
    if n_atomsx == n_atomsy:
       n_atoms = n_atomsx
    else:
       print  "matrix is not square"
       sys.exit()
    plt.figure(figsize=(10,10))
    X=np.arange(1,n_atoms+1);
    cmap = cm.get_cmap('jet')
    Y=np.arange(1,n_atoms+1);
    #print matrix
    #cmax = np.max(matrix)*1.2
    #for i in range(int(n_atoms)):
    #  for j in range(int(n_atoms)):
      #   print matrix
      #   print i,j,matrix[i][j]
    #     if matrix[int(i)][int(j)] == 0.0:
    #         matrix[i][j]=float("-inf")
    #,edgecolors='k')
#colorbar;
    #plt.colorbar()
    #cmax = max(matrix)
    #plt.clim(0,1)
    #plt.xlabel(xname,fontsize=30)
    #plt.ylabel(yname,fontsize=30)
    #plt.title(title,fontsize=30)
    major_ticks = np.arange(1, n_atoms+1,8)
    minor_ticks = np.arange(1, n_atoms+1,8)
    ax = plt.axes()
    #ax.set_xticks(major_ticks)
    #ax.set_xticks(minor_ticks, minor=True)
    #ax.set_yticks(major_ticks)
    #ax.set_yticks(minor_ticks, minor=True)
#plt.grid()
    #ax.grid(which='both')
    #ax.grid(which='minor', alpha=0.2)
    #ax.grid(which='major', alpha=0.5)
    ax.set_yticks([72,124,368,441,491,736], minor=False)
    ax.set_yticks([72,124,368,441,491,736], minor=True)
    ax.yaxis.grid(True, which='major')
    ax.yaxis.grid(True, which='minor')
    ax.set_xticks([72,124,368,441,491,736], minor=False)
    ax.set_xticks([72,124,368,441,491,736], minor=True)
    ax.xaxis.grid(True, which='major')
    ax.xaxis.grid(True, which='minor')
    #plt.axis([0,n_atoms+1, 0, n_atoms+1])
    #plt.xticks(fontsize=5)
    plt.yticks(fontsize=30)
    plt.gca().set_aspect('equal', adjustable='box')

    #cmap.set_bad('white',1.)
    ax = plt.pcolormesh(matrix,vmin = -1, vmax = 1,cmap='RdBu_r')
    plt.colorbar()
    #plt.clim(0,1)
    plt.gca().set_xticks([])
    plt.savefig('%s.png'%(title),dpi=600)
    #plt.show()

def main():
    if len(sys.argv) != 6:
       print "*py pdbfile1 pdbfile xname yname title"
       sys.exit()
    pdbfile1 = sys.argv[1]
    pdbfile2 = sys.argv[2]
    xname = sys.argv[3]
    yname = sys.argv[4]
    title = sys.argv[5]
    #contactmap2 = np.loadtxt(txtfile)
    with open(pdbfile1,'r') as fopen:
         pdb_part = fopen.readlines()
    ca_atoms = get_ca_s_atoms(pdb_part)
    contactmap1 =  compute_contactmap(ca_atoms)
    with open(pdbfile2,'r') as fopen:
         pdb_part = fopen.readlines()
    ca_atoms = get_ca_s_atoms(pdb_part)
    contactmap2 =  compute_contactmap(ca_atoms)
    matrix = merge_matrix(contactmap1,contactmap2,len(ca_atoms))
    print matrix 
    draw_contactmap(matrix,xname,yname,title)
    
if __name__ == '__main__':
    main()

