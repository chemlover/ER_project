import numpy as np
import sys
import os
import matplotlib.pyplot as plt
from matplotlib.pyplot import cm as cm
from math import *
import codecs
#print "*.py pathT  xname yname pathR pciturename num_sim"
filename = sys.argv[1]
#num = int(sys.argv[2])
picturename = sys.argv[2]
os.system("tail -n +4 %s > temp"%(filename))
data=np.loadtxt("temp")
plt.figure(figsize=(10,8))
#plt.rcParams['font.family'] = 'serif'
#plt.rcParams['font.serif'] = ['Times New Roman'] + plt.rcParams['font.serif']
#s='(\xef\xbd\xa1\xef\xbd\xa5\xcf\x89\xef\xbd\xa5\xef\xbd\xa1)\xef\xbe\x89'
#s1=s.decode('utf-8')
#plt.plot(Q,rmsd1,linewidth = 3.0,color = "gold") 
#plt.plot(ra,valuea,linewidth = 3.0,color = "#00a2ff",marker='o',markersize=8,markeredgewidth=3,markeredgecolor="#00a2ff",markerfacecolor="white") 
#plt.plot(anglea,valuea,linewidth = 3.0,color = "#61d836",marker='o',markersize=8,markeredgewidth=3,markeredgecolor="#61d836",markerfacecolor="white")
sim=[]
expi=[]
sime=[]
expe=[]
for i in range(len(data[:,0])):
    sim.append(log(data[i][3]))
    expi.append(log(data[i][1]))
    sime.append(-data[i][3]+data[i][1])
    #sime.append(log(data[i][2]))
    expe.append(0)
plt.plot(data[:,0],sim,linewidth = 5.0,color = "#FF6A6A",marker='o',markersize=0,markeredgewidth=3,markeredgecolor="#FF6A6A",markerfacecolor="white")
plt.plot(data[:,0],expi, 'o', color='black',markersize=5)
xname = "q[A-1]"
yname = "log(I(q))"
#xname = "angle (rad)"
plt.legend(["Fitting","Experimental"],fontsize=20,loc='best')
plt.ylabel(yname,fontsize=20)
#plt.xticks(Q,pdbid,rotation='vertical',fontsize=20)
#plt.xlabel(xname,fontsize=20)
plt.yticks(fontsize=20)
plt.xticks(fontsize=20)
plt.gca().set_xticks([])
plt.tight_layout()
#plt.grid(linestyle='-')
#plt.gca().yaxis.grid(linestyle='-')
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman'] + plt.rcParams['font.serif']
s='(\xef\xbd\xa1\xef\xbd\xa5\xcf\x89\xef\xbd\xa5\xef\xbd\xa1)\xef\xbe\x89'
#s1=s.decode('utf-8')
#plt.gca().invert_yaxis()
plt.savefig('./%s1.png'%(picturename))
plt.figure(figsize=(10,3))
plt.plot(data[:,0],sime,linewidth = 3.0,color = "#FF6A6A",marker='o',markersize=0,markeredgewidth=3,markeredgecolor="#FF6A6A",markerfacecolor="white")
plt.plot(data[:,0],expe,linewidth = 3.0,color = 'black',marker='o',markersize=0,markeredgewidth=3,markeredgecolor="#FF6A6A",markerfacecolor="white")
plt.ylabel("Residual",fontsize=20)
plt.xlabel(xname,fontsize=20)
plt.xticks(fontsize=20)
plt.yticks(fontsize=20)
plt.gca().set_yticks([])
plt.tight_layout()
plt.savefig('./%s2.png'%(picturename))


