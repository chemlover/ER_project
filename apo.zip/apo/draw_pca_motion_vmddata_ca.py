import os
import sys
import numpy as np
import math
import matplotlib.pyplot as plt
from matplotlib.pyplot import cm as cm


def plot_motion(name,n_mode):
    #print len(mode_motion) 
    #n_mode = len(mode_motion)
    #x_axis = np.arange(1,n_atoms*2+2)
    #print n_atoms
    #print n_mode
    #for i in range(n_mode):
    Colors_list = ['b','g','r','y','k']
    Markers_list = ['.','*','d','p','h']
    Linestyles_list = ['-','--','-.',':','-']
    Labels_list = ["PC 1","PC 2","PC 3","PC 4","PC 5"]
    fig=plt.figure(figsize=(15, 15))
    fsize = 40
    pca_file = name.split(".")[0]+str(1)+"."+name.split(".")[1]
    data = np.loadtxt(pca_file)
    norm_coff = max(data[:,1])
    n_atoms = int(max(data[:,0]))
    n_atoms = int(len(data[:,0]))
    x_axis = np.arange(1,n_atoms+1)
    for i in range(n_mode):
        print (n_mode)
        col = Colors_list[i]
        mark = Markers_list[i]
        lin = Linestyles_list[i]
        PC_label = "principal component " + str(i+1)
        pca_file = name.split(".")[0]+str(i+1)+"."+name.split(".")[1]
        y_axis = np.loadtxt(pca_file)[:,1]/norm_coff
        #y_axis = y_pre[0:n_atoms/2]
        print (len(x_axis),len(y_axis))
        #print len(y_pre[n_atoms/2+2:n_atoms+2])
        #y_axis = np.append(y_axis,y_pre[n_atoms/2+2:n_atoms+2])
        print (len(y_axis)
                )#for i in range(n_atoms+4):
        #    if x_pre[i]-pre != 1:
        #       y_axis.append(y_pre[i])   
        #    pre = x_pre[i]
        #print len(x_axis)
        #print len(y_axis)
        plt.plot(x_axis,y_axis,linewidth = 3.0,label = PC_label,color = col,linestyle = lin,marker = mark)
    #plt.xlabel("residue",fontsize=fsize)
    #plt.ylabel("motion",fontsize=fsize)
    ax = plt.gca()
    ax.set_xticks([72,124,368,441,491,736], minor=False)
    ax.set_xticks([72,124,368,441,491,736], minor=True)
    ax.xaxis.grid(True, which='major')
    ax.xaxis.grid(True, which='minor')
    plt.xticks(fontsize=fsize/1.5)
    plt.yticks(fontsize=fsize/1.5)
    #plt.ylim(0,max(mode_motion)+0.1)
    #plt.xlim(min(x_axis),max(x_axis))
    plt.legend(Labels_list,fontsize=fsize/1.5)
    plt.savefig('./motionf.png',dpi=600)

#plt.show()
def main():
    inputfile = sys.argv[1]
    n_mode = int(sys.argv[2])
    plot_motion(inputfile,n_mode)

if __name__ == '__main__':
    main()
