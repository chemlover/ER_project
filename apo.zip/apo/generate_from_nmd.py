import os
import sys
import numpy as np
import math
#import matplotlib.pyplot as plt
#from matplotlib.pyplot import cm as cm

def print_pca_nmd_condition(lines):
     mode = []
     for line in lines:
        print (len(line.split()))
        if line.split()[0] ==  "atomnames":
           atomnames = line.split()
        elif line.split()[0] == "resnames":
           resnames = line.split()
        elif line.split()[0] == "resids":
           resids = line.split()
        elif line.split()[0] == "chainids":
           chainids = line.split()
        elif line.split()[0] == "bfactors":
           bfactors = line.split()
        elif line.split()[0] == "coordinates":
           coordinates = line.split()
        elif line.split()[0] == "mode":
           print (line.split()[1])
           if line.split()[1] == str(1):
              mode1 = line.split()
              mode.append(mode1)
           elif line.split()[1] == str(2):
              mode2 = line.split()
              mode.append(mode2)
           elif line.split()[1] == str(3):
              mode3 = line.split()
              mode.append(mode3)
           elif line.split()[1] == str(4):
              mode4 = line.split()
              mode.append(mode4)
           elif line.split()[1] == str(5):
              mode5 = line.split()
           #print resids.split()[-1]
              mode.append(mode5)
     return (atomnames,resnames,resids,chainids,bfactors,coordinates,mode1,mode2,mode3,mode4,mode5,mode,int(resids[-1]))

def get_motion_resiude(atomnames,resids,mode,n_atoms):
    motion = np.zeros(n_atoms)
    length = len(atomnames)
    for i in range(1,length):
        if atomnames[i] == 'CA':
           j = int(resids[i])-1
           k = (i-1)*3+2
           dx = float(mode[k+1])
           dy = float(mode[k+2]) 
           dz = float(mode[k+3])
           motion_resi = math.sqrt(dx**2 + dy**2 + dz**2)
           #print motion_resi
           motion[j] = motion_resi
    return motion 

def makepdb_coordinate(atomnames,resnames,resids,chainids,bfactors,coordinates):
    n_lines = len(atomnames)
    data = ''
    for i in range(1,n_lines):
        atomname=atomnames[i]
        resname= resnames[i]
        resid= resids[i]
        chainid=chainids[i]
        bfactor=bfactors[i]
        k=(i-1)*3
        x=coordinates[k+1]
        y=coordinates[k+2]
        z=coordinates[k+3]
        transfer = "ATOM" + str(i).rjust(7," ") + "  " + atomname.ljust(4," ") + resname + " " + chainid + resid.rjust(4," ") + x.rjust(12," ") + y.rjust(8," ")+z.rjust(8," ")+ "  1.00"+bfactor.rjust(6," ")+atomname[0].rjust(12," ")+'\n'
        data += transfer
    return data

def makepdb_mode(atomnames,resnames,resids,chainids,bfactors,coordinates,mode):
    n_lines = len(atomnames)
    data = ''
    for i in range(1,n_lines):
        atomname=atomnames[i]
        resname= resnames[i]
        resid= resids[i]
        chainid=chainids[i]
        bfactor=bfactors[i]
        k=(i-1)*3
        x=str(float(coordinates[k+1]) + float(mode[k+3]))
        y=str(float(coordinates[k+2]) + float(mode[k+4]))
        z=str(float(coordinates[k+3]) + float(mode[k+5]))
        transfer = "ATOM" + str(i).rjust(7," ") + "  " + atomname.ljust(4," ") + resname + " " + chainid + resid.rjust(4," ") + x.rjust(12," ") + y.rjust(8," ")+z.rjust(8," ")+ "  1.00"+bfactor.rjust(6," ")+atomname[0].rjust(12," ") + '\n'
        data += transfer
    return data

def writepdb(pdbname,data):
    with open(pdbname,"w") as fopen:
         fopen.writelines(data)

def plot_motion(mode_motion,n_atoms):
    n_mode = len(mode_motion)
    x_axis = np.arange(1,n_atoms)
    #for i in range(n_mode):
    Colors_list = ['b','g','r','y','k']
    Markers_list = ['.','*','d','p','h']
    Linestyles_list = ['-','--','-.',':','-']
    Labels_list = ["principal component 1","principal component 2","principal component 3","principal component 4","principal component 5"]
    fig=plt.figure(figsize=(20, 15))
    fsize = 40
    for i in range(n_mode):
        col = Colors_list[i]
        mark = Markers_list[i]
        lin = Linestyles_list[i]
        PC_label = "principal component " + str(i+1)
        y_axis = mode_motion[i]
        plt.plot(x_axis,y_axis,linewidth = 3.0,label = PC_label,color = col,linestyle = lin,marker = mark)
    plt.xlabel("residue",fontsize=fsize)
    plt.ylabel("motion",fontsize=fsize)
    plt.xticks(fontsize=fsize)
    plt.yticks(fontsize=fsize)
    plt.legend(Labels_list,fontsize=fsize/2)
#plt.show()
    plt.savefig('./motion.png')

def main():
    inputfile = sys.argv[1]
    with open (inputfile,"r") as fopen:
     lines = fopen.readlines()
    motion = []
    (atomnames,resnames,resids,chainids,bfactors,coordinates,mode1,mode2,mode3,mode4,mode5,mode,n_atoms) =  print_pca_nmd_condition(lines)
    refer_data = makepdb_coordinate(atomnames,resnames,resids,chainids,bfactors,coordinates)
    writepdb("refer.pdb",refer_data)
    for i in range(5):
        mode_data = makepdb_mode(atomnames,resnames,resids,chainids,bfactors,coordinates,mode[i])
        mode_name = "mode" + str(i+1) + ".pdb"
        writepdb(mode_name,mode_data)
        mode_motion = get_motion_resiude(atomnames,resids,mode[i],n_atoms)
        #print len(mode_motion)
        motion.append(mode_motion)
    np.savetxt("motion.txt",motion,fmt="%.6f",delimiter=" ")
    #plot_motion(motion,n_atoms)

if __name__ == '__main__':
    main()
