import numpy as np
import sys
import os
import matplotlib.pyplot as plt
from matplotlib.pyplot import cm as cm
#print "*.py pathT  xname yname pathR pciturename num_sim"
filename = sys.argv[1]
#xname = sys.argv[2]
#yname = sys.argv[3]
#PdbID = sys.argv[2]
#folder = sys.argv[3]
#inputfile = sys.argv[4]
#picturename = sys.argv[4]
#num = int(sys.argv[5])
Colors_list = ['b','g','r','c','m','y','k','c','b','r']
Markers_list = ['.','*','d','p','h','o','s','x','p','h']
Linestyle_list = ['-','--','-.',':']
#length = len(folder_list)
#for PdbID in PdbID_list
fig=plt.figure(figsize=(7.5, 7.5))
col = Colors_list[1]
mark = Markers_list[1]
listy = Linestyle_list[ 1 % 4 ]
#    inputfile = pathT + '/'+ PdbID + '/' + folder + '.txt'
#    inputfile = pathT + '/'+ PdbID +  '/' + folder + '.txt'
#windows = np.arange(1,num+1)
Q = np.loadtxt(filename)
num = len(Q)
windows = np.arange(1,num+1)
#Q = np.loadtxt(filename)
#windows = np.arange(1,len(Q)+1)
#plt.ylabel(yname,fontsize=50)
#plt.xlabel(xname,fontsize=50)
plt.xticks(fontsize=20)
plt.yticks(fontsize=20)
    #plt.xlabel(xname,fontsize=5)
#plt.title(picturename,fontsize=20)
    #plt.legend(folder_list,fontsize=5)       
    #print Q
    #Q = Q[np.argsort(Q)] 
    #print Q
#plt.plot(windows,Q,linewidth = 3.0,label = yname,color = col,linestyle = listy,marker = mark)
#plt.bar(windows,height = Q)
    #plt.title(picturename)
#plt.xlabel(xname,fontsize=20)
#plt.ylabel(yname,fontsize=20)
plt.bar(windows,Q,align='center', alpha=0.5,linewidth=1,edgecolor="k",color="#00a2ff")
#plt.legend(folder_list)
plt.xlim(0.5,5.5)
#plt.xticks(fontsize=10)
#plt.yticks(fontsize=10)
#plt.xlim([0.5,num-0.5])
plt.savefig('./dist.png',dpi=600)

