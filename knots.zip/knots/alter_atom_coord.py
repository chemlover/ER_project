import os
import sys
#import mdtraj as md
import sys
import numpy as np

inputfile = sys.argv[1]
#i00dn = sys.argv[3]
outputfile = sys.argv[2]
##compute RMSF
#1111t = md.load('movie.pdb');
#t = t_total[300::1]

#t_top = t.topology;
#t_ind = t_top.select("name CA")
#t.superpose(atom_indices=t_ind)
#rmsf = md.rmsf(t, t, frame=-1, atom_indices=t_ind)


#outputfile = "model" + idn +".pdb"
#pdbid = sys.argv[2]
#model= "model" + idn 
#data = "PFRMAT TS\nTARGET "+pdbid+"\nAUTHOR Frustration_Refine\nMODEL  "+idn+"\nPARENT NA\n"
data = ""
#startid = int(sys.argv[3])
#with open(inputfile,"r") as fopen:
     #for line in fopen.readlines():
         #if len(line) > 70:
            #resid=int(line[23:26].strip())
            #break
         #else:
         #   data += line            
atomid = 0
id_line = 0 
with open(inputfile,"r") as fopen:
     for line in fopen.readlines():
         if len(line) > 70 and line[0:4]=="ATOM":
               id_line += 1
            #if id_line <= 290:
               atomid += 1
               xnew = float(line[30:38]) + 60
               ynew = float(line[38:46]) + 60
               znew = float(line[46:54]) + 60
               data += line[0:30] + str(xnew).rjust(8," ") + str(ynew).rjust(8," ") + str(znew).rjust(8," ") + line[54:81]
         else:
               data += line
data += "TER\nEND\n"
with open(outputfile,"w") as fwrite:
     fwrite.writelines(data)
