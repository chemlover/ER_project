import os
import sys
#import mdtraj as md
import sys
import numpy as np

inputfile = sys.argv[1]
#i00dn = sys.argv[3]
outputfile = sys.argv[2]
##compute RMSF
#1111t = md.load('movie.pdb');
#t = t_total[300::1]

#t_top = t.topology;
#t_ind = t_top.select("name CA")
#t.superpose(atom_indices=t_ind)
#rmsf = md.rmsf(t, t, frame=-1, atom_indices=t_ind)


#outputfile = "model" + idn +".pdb"
#pdbid = sys.argv[2]
#model= "model" + idn 
#data = "PFRMAT TS\nTARGET "+pdbid+"\nAUTHOR Frustration_Refine\nMODEL  "+idn+"\nPARENT NA\n"
data = ""
startid = int(sys.argv[3])
with open(inputfile,"r") as fopen:
     for line in fopen.readlines():
         if len(line) > 70:
            resid=int(line[23:26].strip())
            break
         else:
            data += line            
with open(inputfile,"r") as fopen:
     for line in fopen.readlines():
         if len(line) > 70:
            resido =int(line[23:26].strip())
            data += line[0:22] + str(resido-resid+startid).rjust(4," ") + line[26:81]
data += "TER\nEND\n"
with open(outputfile,"w") as fwrite:
     fwrite.writelines(data)
