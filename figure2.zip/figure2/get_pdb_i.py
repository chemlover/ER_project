import os 
import sys
def get_lines_pdbfile(pdbfile):
    nlines = 0
    with open(pdbfile,"r") as fopen:
         for line in fopen.readlines():
             nlines += 1
             if line.split()[0] == "END" or line.split()[0] == "ENDMDL":
                return nlines

def getline_range(filename, line1, line2):
    assert(line1 <= line2)
    nline=line2-line1+1
    exeline="head -n"+str(line2)+" "+filename+" | tail -n"+str(nline) ;
    #print exeline
    stdout=os.popen(exeline).readlines()
    return stdout

def get_pdbfile_i(pdbfile,i,n_lines):
     #   nline=get_nline_snapshot(pdbfile)
        line_start = 1 + n_lines*i ; line_end = n_lines*(i+1)
        print (n_lines)
        pdb_part=getline_range(pdbfile, line_start, line_end)
        return pdb_part

def get_pdbfile_ij(pdbfile,i,j,n_lines):
    print (n_lines,i,j)
    line_start = 1 + n_lines*i ; line_end = n_lines*(j+1)
    pdb_part=getline_range(pdbfile, line_start, line_end)
    return pdb_part

def main():
   trajfile = sys.argv[1]
   outputfile = sys.argv[2]
   i = int(sys.argv[3])
   #j = int(sys.argv[4])
   #os.system("head -n20000 %s > temp.pdb"%(trajfile))
   n_lines = get_lines_pdbfile(trajfile)
   lines = get_pdbfile_i(trajfile,i,n_lines)
   with open(outputfile,'w') as fwrite:
        fwrite.writelines(lines)

if __name__ == '__main__':
    main()

