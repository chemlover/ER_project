for i in $(seq 0 31);do 
    let "j=i*500+500"
    head -n$j vector_backup.txt | tail -n250>> vector.txt
done
