import os 
import sys
import numpy as np 
import math

def get_lines_pdbfile(pdbfile):
    nlines = 0
    with open(pdbfile,"r") as fopen:
         for line in fopen.readlines():
             nlines += 1
             if line.split()[0] == "END":
                return nlines

def getline_range(filename, line1, line2):
    assert(line1 <= line2)
    nline=line2-line1+1
    exeline="head -n"+str(line2)+" "+filename+" | tail -n"+str(nline) ;
    #print exeline
    stdout=os.popen(exeline).readlines()
    return stdout

def get_pdbfile_i(pdbfile,i,n_lines):
     #   nline=get_nline_snapshot(pdbfile)
        line_start = 1 + n_lines*i ; line_end = n_lines*(i+1)
        pdb_part=getline_range(pdbfile, line_start, line_end)
        return pdb_part

def get_ca_atoms(pdb_part):
    ca_atoms = []
    for line in pdb_part:
      line_part = line.split()
      if len(line_part) > 2:
        if line_part[2] == "CA" or line_part[2] == "S":
           x = float(line[30:38])
           y = float(line[38:46])
           z = float(line[46:54])
           atom = [x,y,z]
           ca_atoms.append(atom)
    return ca_atoms

def get_center_mass(ca_atoms,id_start,id_end):
    length = id_end - id_start + 1.0
    x_center = 0
    y_center = 0
    z_center = 0
    for i in range(id_start-1,id_end):
        x_center += ca_atoms[i][0]/length
        y_center += ca_atoms[i][1]/length
        z_center += ca_atoms[i][2]/length
          
    return [x_center,y_center,z_center]

def get_center_mass_array(ca_atoms,id_array):
    length = len(id_array)
    x_center = 0
    y_center = 0
    z_center = 0
    for i in id_array:
        #print len(ca_atoms)
        #print i
        x_center += ca_atoms[i-1][0]/length
        y_center += ca_atoms[i-1][1]/length
        z_center += ca_atoms[i-1][2]/length
    return [x_center,y_center,z_center]

def vector(p1, p2):
    return [p2[0]-p1[0], p2[1]-p1[1], p2[2]-p1[2]]

def vabs(a):
    return math.sqrt(pow(a[0],2)+pow(a[1],2)+pow(a[2],2))

def v_product(p1,p2):
    return p1[0]*p2[0]+p1[1]*p2[1]+p1[2]*p2[2]

def vangle(p1,p2):
    return math.acos(v_product(p1,p2)/vabs(p1)/vabs(p2))*180/3.1415926535

def vproduct(a, b):
    if type(a)==type([]) and type(b)==type([]):
        return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]
    elif type(b)==type([]):
        return [a*b[0], a*b[1], a*b[2]]
    elif type(a)==type([]):
        return [a[0]*b, a[1]*b, a[2]*b]
    return a*b

def vcross_product(a, b):
    cx = a[1]*b[2]-a[2]*b[1]
    cy = a[2]*b[0]-a[0]*b[2]
    cz = a[0]*b[1]-a[1]*b[0]
    return [cx, cy, cz];


def dihedral_angle(v1, v2, v3):
    n1 = vcross_product(v1, v2)
    n2 = vcross_product(v2, v3)
    y = vproduct( vproduct(vabs(v2), v1), n2 )
    x = vproduct( n1, n2 )
    return math.atan2(y, x)


def calc_dihedral_angle(p1, p2, p3, p4):
    v1 = vector(p1, p2)
    v2 = vector(p2, p3)
    v3 = vector(p3, p4)
    return 180*dihedral_angle(v1, v2, v3)/3.14159265358979

def vector_value(p1_center1,p1_center2,p2_center1,p2_center2):
    p1 = vector(p1_center1,p1_center2)
    p2 = vector(p2_center1,p2_center2)
    dist_p1 = vabs(p1)
    dist_p2 = vabs(p2)
    angle = math.acos(v_product(p1,p2)/dist_p1/dist_p2)*180/3.1415926535
    dihedral_p1 = calc_dihedral_angle(p1_center1,p2_center1,p2_center2,p1_center2)
    dihedral_p2 = calc_dihedral_angle(p2_center1,p1_center1,p1_center2,p2_center2)
    return dist_p1,dist_p2,angle,dihedral_p1,dihedral_p2


def get_file_len(filename):
    exeline="wc -l "+filename ;
    stdout=os.popen(exeline).readline();
    stdout=stdout.split()
    return int(stdout[0])
    
def calcu_vector_snapshot(pdb_part):
    DBD1_start = 1
    DBD1_end = 71
    hinge1_start = 72
    hinge1_end = 124
    LBD1_start = 125
    LBD1_end = 368
    DBD2_start = 369
    DBD2_end = 439
    hinge2_start = 440
    hinge2_end = 492
    LBD2_start = 493
    LBD2_end = 736
    DNA1_array=[737,772]
    DNA2_array=[754,755]
    ca_atoms = get_ca_atoms(pdb_part)
    DBD1 = get_center_mass(ca_atoms,DBD1_start,DBD1_end)
    #hinge1 = get_center_mass(ca_atoms,hinge1_start,hinge1_end)
    hinge11 = ca_atoms[hinge1_start-1]
    hinge12 = ca_atoms[hinge1_end-1]
    LBD1 = get_center_mass(ca_atoms,LBD1_start,LBD1_end)
    DBD2 = get_center_mass(ca_atoms,DBD2_start,DBD2_end) 
    #hinge2 = get_center_mass(ca_atoms,hinge2_start,hinge2_end)
    hinge21 = ca_atoms[hinge2_start-1]
    hinge22 = ca_atoms[hinge2_end-1]
    LBD2 = get_center_mass(ca_atoms,LBD2_start,LBD2_end)
    DNA1 = get_center_mass_array(ca_atoms,DNA1_array)
    DNA2 = get_center_mass_array(ca_atoms,DNA2_array)
    dist_LD1,dist_LD2,angle_LD_chain,diheadral_LD1,dihedral_LD2 = vector_value(DBD1,LBD1,DBD2,LBD2)
    dist_hinge1,dist_hinge2,angle_hinge_chain,diheadral_hinge1,dihedral_hinge2 = vector_value(hinge11,hinge12,hinge21,hinge22)
    dist_DD,dist_LL,angle_LLDD_chain,diheadral_DD,dihedral_LL = vector_value(DBD1,DBD2,LBD1,LBD2)
    dist_DD,dist_DNA,angle_DDDNA_chain,diheadral_DD,dihedral_DNA = vector_value(DBD1,DBD2,DNA1,DNA2)
    return dist_LD1,dist_LD2,angle_LD_chain,diheadral_LD1,dihedral_LD2,dist_hinge1,dist_hinge2,angle_hinge_chain,diheadral_hinge1,dihedral_hinge2,dist_DD,dist_LL,angle_LLDD_chain,diheadral_DD,dihedral_LL,dist_DD,dist_DNA,angle_DDDNA_chain,diheadral_DD,dihedral_DNA

def calu_vector_traj(trajfile):
    os.system("head -n200000 %s > temp.pdb"%(trajfile))
    nlines = get_lines_pdbfile("temp.pdb")
    filelines = get_file_len(trajfile)
    n_snapshots = filelines/nlines
    out = open("vector.txt","w")
    for i in range(n_snapshots):
        pdb_part = get_pdbfile_i(trajfile,i,nlines)
        dist_LD1,dist_LD2,angle_LD_chain,diheadral_LD1,dihedral_LD2,dist_hinge1,dist_hinge2,angle_hinge_chain,diheadral_hinge1,dihedral_hinge2,dist_DD,dist_LL,angle_LLDD_chain,diheadral_DD,dihedral_LL,dist_DD,dist_DNA,angle_DDDNA_chain,diheadral_DD,dihedral_DNA =  calcu_vector_snapshot(pdb_part)
        out.write(str(dist_LD1) + " " + str(dist_LD2) + " "+ str(angle_LD_chain) + " " + str(diheadral_LD1) + " " + str(dihedral_LD2) + " " + str(dist_hinge1) + " " + str(dist_hinge2) + " " + str(angle_hinge_chain) + " " + str(diheadral_hinge1) + " " + str(dihedral_hinge2) + " " + str(dist_DD) + " " + str(dist_LL) + " " + str(angle_LLDD_chain) + " " + str(diheadral_DD) + " " + str(dihedral_LL) + " " + str(dist_DD) + " " + str(dist_DNA) + " " + str(angle_DDDNA_chain) + " " + str(diheadral_DD) + " " + str(dihedral_DNA) + "\n")
    out.close()

def main():
    trajfile = sys.argv[1]
    calu_vector_traj(trajfile)

if __name__ == '__main__':
    main()
   
