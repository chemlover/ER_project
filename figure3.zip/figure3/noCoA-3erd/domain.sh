awk '{print $2}' ecoul_domain > ecoul_DBD
awk '{print $3}' ecoul_domain > ecoul_hinge
awk '{print $4}' ecoul_domain > ecoul_LBD
