import os
import numpy as np
import sys 
inputfile=sys.argv[1]
data=np.loadtxt(inputfile)
T=300
RT=0.001987*T
c_0=1.0/1660
r_site=data[:,0][4:17]
e_site=data[:,1][4:17]
print(r_site)
Keq_b=4.0*np.pi*np.trapz(np.exp(e_site/RT)*r_site*r_site,r_site)
Delta_G=-RT*np.log(c_0*Keq_b)
print (Keq_b,Delta_G)
print (-RT*np.log(20000000),-RT*np.log(500000000))
