awk '{print $1}' $1 > DBD
awk '{print $2}' $1 > hinge
awk '{print $3}' $1 > LBD
