T = 300
disp(T)
qa_name ='p_total';%new rxn co
binN=25;
color={'r','m','g','b'};
dih_range=16:22;
n_T=16;
cv=zeros(n_T,1); cm=colormap(jet(n_T))
curve_shift_flag=0; q0_shift=0.55;
cutoff=20;
scrnsize = get(0,'ScreenSize'); 
fsize=40; tsize=16;
index = 1
prefix = 'noCoA-3erd' 
qa_name_label = 'distance '
yname = 'free energy'
%qa_name = 'e_total';qa_name_label = 'energy'
%qa_name = 'ecoult_total';qa_name_label = 'ecoul'
%qa_name = 'ecouldbdt_total';qa_name_label = 'ecoul DBD '
%qa_name = 'ecouldbdb_total';qa_name_label = 'ecoul DBD A'
%qa_name = 'ecouldbdt_total';qa_name_label = 'ecoul DBD B'
%qa_name = 'dbd_total';qa_name_label = 'dbd contact'
%qa_name = 'hinge_total';qa_name_label = 'hinge contact'
%qa_name = 'pc3projection.txt';qa_name_label='PC3'
%qa_name_label = 'Qc'
%for i_label=1
%sim_label = sim_labels(i_label);
%pdbID_upper = pdb_array{i_label};
path = sprintf('/home/xc25/Data_dealing/100bp_right');
path = sprintf('/home/xc25/Data_dealing/PU_1_variable/angle_bias/angle_P')
path = '/home/xc25/Research/estrogen_receptor/figure3/noCoA-3erd'
filename = sprintf('%s/%s',path, qa_name); qa = load(filename);
%filename = sprintf('%s/dbd_total',path); qb = load(filename);
%filename = sprintf('%s/hinge_total',path); qc = load(filename);
if strcmp(qa_name,'dih')
   qa=(mean(qa(:,dih_range)'))';
end
filename = sprintf('%s/p_total',path); q = load(filename);
%qa=qb-qc
Nsample = length(q);
filename=sprintf('%s/%s_%d_pmf.dat',path,prefix,T); 
FF=load(filename); qx=FF(:,1);  Fy = FF(:,2); nbin=length(qx);
dq=qx(2)-qx(1); qmin=qx(1)-dq/2; qmax= qx(nbin)+dq/2;
Py=exp(-Fy/(0.001987*T)); P_norm = sum(Py); Py=Py/P_norm;
pi_sample = zeros(Nsample,1); ni_sample = zeros(nbin, 1);


for i_bin= 1:nbin
    qi_min = qmin + (i_bin-1)*dq; qi_max= qi_min + dq;
    ids = find( q >= qi_min & q < qi_max ) ;    
    ni_sample(i_bin) = length(ids);        
    if ni_sample(i_bin) > 0
       pi_sample(ids) = Py(i_bin)/ni_sample(i_bin);
    end
end

fprintf('probability = %.3f\n', sum(pi_sample));
qa_lin=linspace(min(qa), max(qa),binN);
count_qa=zeros(binN,1);
[~,bin_index_x]=histc(qa, qa_lin);

for i_sample=1:Nsample
    
    x=bin_index_x(i_sample);
    count_qa(x) = count_qa(x) + pi_sample(i_sample);
   
end

fprintf('Total probability for new coordinate is %.3f\n',sum(count_qa));
F_qa=-0.001987*T*log(count_qa); ids = (F_qa>= cutoff); F_qa(ids) = cutoff;
     dlmwrite([path,'/qa.txt'],qa_lin)
        dlmwrite([path,'/qb.txt'],F_qa-min(F_qa))
%concentration correction
for i = 1:binN 
    if qa_lin(i) > 15
    F_qa_corr(i)=F_qa(i)+2*0.001987*T*log(qa_lin(i)/15);
    else
    F_qa_corr(i)=F_qa(i);
    end
end
F_qa_corr(i)

if curve_shift_flag==0;
   Fmin = min(F_qa); id_shift = find( F_qa == Fmin );
else
   [~,id_shift]=min(abs(qa_lin-q0_shift));
end

plot(qa_lin,F_qa_corr-min(F_qa_corr),'color',cm(index+13,:),'linewidth',4,'linestyle','-'),hold on;

plot(qa_lin, F_qa-F_qa(id_shift(1)),'color', cm(index+13,:), 'linewidth', 4,'linestyle','-.');   hold on;

%plot(qa_lin, F_qa-F_qa(1),'color', cm(index+13,:), 'linewidth', 4);   hold on;
fsize=30; tsize=16;
xlabel(qa_name_label, 'fontsize', fsize); ylabel('Free energy (kcal/mol)', 'fontsize', fsize); title(['Free energy with ',qa_name_label], 'fontsize', fsize);set(gca,'fontsize',fsize)
T = 300
disp(T)
qa_name ='p_total';%new rxn co
binN=25;
color={'r','m','g','b'};
dih_range=16:22;
n_T=16;
cv=zeros(n_T,1); cm=colormap(jet(n_T))
curve_shift_flag=0; q0_shift=0.55;
cutoff=20;
scrnsize = get(0,'ScreenSize'); 
fsize=25; tsize=16;
index = 1
prefix = 'nocoa_3ert' 
qa_name_label = 'distance '
%qa_name_label="dbd-hinge"
yname = 'free energy'
%qa_name = 'e_total';qa_name_label = 'energy'
%qa_name = 'ecoult_total';qa_name_label = 'ecoul'
%qa_name = 'ecouldbdt_total';qa_name_label = 'ecoul DBD '
%qa_name = 'ecouldbdb_total';qa_name_label = 'ecoul DBD A'
%qa_name = 'ecouldbdt_total';qa_name_label = 'ecoul DBD B'
%qa_name = 'dbd_total';qa_name_label = 'dbd contact'
%qa_name = 'hinge_total';qa_name_label = 'hinge contact'
%qa_name = 'pc3projection.txt';qa_name_label='PC3'
%qa_name_label = 'Qc'
%for i_label=1
%sim_label = sim_labels(i_label);
%pdbID_upper = pdb_array{i_label};
path = sprintf('/home/xc25/Data_dealing/100bp_right');
path = sprintf('/home/xc25/Data_dealing/PU_1_variable/angle_bias/angle_P')
path = '/home/xc25/Research/estrogen_receptor/figure3/nocoa_3ert'
%qa_name = 'pc1projection.txt';qa_name_label='PC1'
filename = sprintf('%s/%s',path, qa_name); qa = load(filename);     
%filename = sprintf('%s/dbd_total',path); qb = load(filename);
%filename = sprintf('%s/hinge_total',path); qc = load(filename);
%filename = sprintf('%s/pc1projection.txt',path); qc = load(filename);
if strcmp(qa_name,'dih')
   qa=(mean(qa(:,dih_range)'))';
end
%qa=qb-qc
filename = sprintf('%s/p_total',path); q = load(filename);
Nsample = length(q);
filename=sprintf('%s/%s_%d_pmf.dat',path,prefix,T); 
FF=load(filename); qx=FF(:,1);  Fy = FF(:,2); nbin=length(qx);
dq=qx(2)-qx(1); qmin=qx(1)-dq/2; qmax= qx(nbin)+dq/2;
Py=exp(-Fy/(0.001987*T)); P_norm = sum(Py); Py=Py/P_norm;
pi_sample = zeros(Nsample,1); ni_sample = zeros(nbin, 1);


for i_bin= 1:nbin
    qi_min = qmin + (i_bin-1)*dq; qi_max= qi_min + dq;
    ids = find( q >= qi_min & q < qi_max ) ;    
    ni_sample(i_bin) = length(ids);        
    if ni_sample(i_bin) > 0 
       pi_sample(ids) = Py(i_bin)/ni_sample(i_bin);
    end
end

fprintf('probability = %.3f\n', sum(pi_sample));
qa_lin=linspace(min(qa), max(qa),binN);
count_qa=zeros(binN,1);
[~,bin_index_x]=histc(qa, qa_lin);

for i_sample=1:Nsample
    
    x=bin_index_x(i_sample);
    count_qa(x) = count_qa(x) + pi_sample(i_sample);
   
end

fprintf('Total probability for new coordinate is %.3f\n',sum(count_qa));
F_qa=-0.001987*T*log(count_qa); ids = (F_qa>= cutoff); F_qa(ids) = cutoff;

if curve_shift_flag==0;
   Fmin = min(F_qa); id_shift = find( F_qa == Fmin );
else
   [~,id_shift]=min(abs(qa_lin-q0_shift));
end
%concentration correction
for i = 1:binN
    if qa_lin(i) > 15
    F_qa_corr(i)=F_qa(i)+2*0.001987*T*log(qa_lin(i)/15)
 
    else
    F_qa_corr(i)=F_qa(i)
end
end

plot(qa_lin,F_qa_corr-min(F_qa_corr),'color',cm(index,:),'linewidth',4,'linestyle','-'),hold on;


plot(qa_lin, F_qa-F_qa(id_shift(1)),'color', cm(index,:), 'linewidth', 4,'linestyle','-.');   hold on;

%plot(qa_lin, F_qa-F_qa(id_shift(1)),'color', cm(index,:), 'linewidth', 4);   hold on;
%plot(qa_lin, F_qa-F_qa(1),'tcolor', cm(index,:), 'linewidth', 4);   hold on;
fsize=30; tsize=16;
xlabel(qa_name_label, 'fontsize', fsize); ylabel('Free energy (kcal/mol)', 'fontsize', fsize); title(['Free energy with ',qa_name_label], 'fontsize', fsize);set(gca,'fontsize',fsize)

%legend("after correction","before correction")
xlim([0 95])
%ylim([-20 0])
%ylim([min(F_qa-F_qa(id_shift(1))),0])
saveas(gcf,[path,'/','1d-',prefix,'-',qa_name_label,'-',yname,'.png'])
T = 300
disp(T)
qa_name ='p_total';%new rxn co
binN=25;
color={'r','m','g','b'};
dih_range=16:22;
n_T=16;
cv=zeros(n_T,1); cm=colormap(jet(n_T))
curve_shift_flag=0; q0_shift=0.55;
cutoff=20;
scrnsize = get(0,'ScreenSize'); 
fsize=25; tsize=16;
index = 8
prefix = 'noCoA_lack_one_hinge' 
qa_name_label = 'distance '
%qa_name_label="dbd-hinge"
yname = 'free energy'
%qa_name = 'e_total';qa_name_label = 'energy'
%qa_name = 'ecoult_total';qa_name_label = 'ecoul'
%qa_name = 'ecouldbdt_total';qa_name_label = 'ecoul DBD '
%qa_name = 'ecouldbdb_total';qa_name_label = 'ecoul DBD A'
%qa_name = 'ecouldbdt_total';qa_name_label = 'ecoul DBD B'
%qa_name = 'dbd_total';qa_name_label = 'dbd contact'
%qa_name = 'hinge_total';qa_name_label = 'hinge contact'
%qa_name = 'pc3projection.txt';qa_name_label='PC3'
%qa_name_label = 'Qc'
%for i_label=1
%sim_label = sim_labels(i_label);
%pdbID_upper = pdb_array{i_label};
path = sprintf('/home/xc25/Data_dealing/100bp_right');
path = sprintf('/home/xc25/Data_dealing/PU_1_variable/angle_bias/angle_P')
path = '/home/xc25/Data_dealing/ER_project/ER_5_old/ER_bias/noCoA_lack_one_hinge'
%qa_name = 'pc1projection.txt';qa_name_label='PC1'
filename = sprintf('%s/%s',path, qa_name); qa = load(filename);     
%filename = sprintf('%s/dbd_total',path); qb = load(filename);
%filename = sprintf('%s/hinge_total',path); qc = load(filename);
%filename = sprintf('%s/pc1projection.txt',path); qc = load(filename);
if strcmp(qa_name,'dih')
   qa=(mean(qa(:,dih_range)'))';
end
%qa=qb-qc
filename = sprintf('%s/p_total',path); q = load(filename);
Nsample = length(q);
filename=sprintf('%s/%s_%d_pmf.dat',path,prefix,T); 
FF=load(filename); qx=FF(:,1);  Fy = FF(:,2); nbin=length(qx);
dq=qx(2)-qx(1); qmin=qx(1)-dq/2; qmax= qx(nbin)+dq/2;
Py=exp(-Fy/(0.001987*T)); P_norm = sum(Py); Py=Py/P_norm;
pi_sample = zeros(Nsample,1); ni_sample = zeros(nbin, 1);


for i_bin= 1:nbin
    qi_min = qmin + (i_bin-1)*dq; qi_max= qi_min + dq;
    ids = find( q >= qi_min & q < qi_max ) ;    
    ni_sample(i_bin) = length(ids);        
    if ni_sample(i_bin) > 0 
       pi_sample(ids) = Py(i_bin)/ni_sample(i_bin);
    end
end

fprintf('probability = %.3f\n', sum(pi_sample));
qa_lin=linspace(min(qa), max(qa),binN);
count_qa=zeros(binN,1);
[~,bin_index_x]=histc(qa, qa_lin);

for i_sample=1:Nsample
    
    x=bin_index_x(i_sample);
    count_qa(x) = count_qa(x) + pi_sample(i_sample);
   
end

fprintf('Total probability for new coordinate is %.3f\n',sum(count_qa));
F_qa=-0.001987*T*log(count_qa); ids = (F_qa>= cutoff); F_qa(ids) = cutoff;

if curve_shift_flag==0;
   Fmin = min(F_qa); id_shift = find( F_qa == Fmin );
else
   [~,id_shift]=min(abs(qa_lin-q0_shift));
end
%concentration correction
for i = 1:binN
    if qa_lin(i) > 15
    F_qa_corr(i)=F_qa(i)+2*0.001987*T*log(qa_lin(i)/15)
 
    else
    F_qa_corr(i)=F_qa(i)
end
end

%plot(qa_lin,F_qa_corr-min(F_qa_corr),'color',cm(index,:),'linewidth',4,'linestyle','-'),hold on;
%plot(qa_lin, F_qa-F_qa(id_shift(1)),'color', cm(index,:), 'linewidth', 4,'linestyle','-.');   hold on;

%plot(qa_lin, F_qa-F_qa(id_shift(1)),'color', cm(index,:), 'linewidth', 4);   hold on;
%plot(qa_lin, F_qa-F_qa(1),'tcolor', cm(index,:), 'linewidth', 4);   hold on;
fsize=30; tsize=16;
xlabel(qa_name_label, 'fontsize', fsize); ylabel('Free energy (kcal/mol)', 'fontsize', fsize); title(['Free energy with ',qa_name_label], 'fontsize', fsize);set(gca,'fontsize',fsize)
%legend("hinge nocharge after correction"," hinge nocharge before correction","intact correction","intact before correction","lack one hinge after  correction"," lack one hinge before correction")
set(gca,'fontsize',fsize/2)
%legend("after correction","before correction")
xlim([0 95])
%ylim([-20 0])
%ylim([min(F_qa-F_qa(id_shift(1))),0])
saveas(gcf,[path,'/','1d-',prefix,'-',qa_name_label,'-',yname,'.png'])