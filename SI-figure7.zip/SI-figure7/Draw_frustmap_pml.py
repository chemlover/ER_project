import numpy as np
import pandas
import matplotlib.pyplot as plt
from matplotlib.pyplot import cm as cm
import sys
import math
import os
#np.set_printoptions(threshold=np.nan)


def convert_frustmap_pml(inputfile,outputfile):
    data = np.loadtxt(inputfile)
    fpml = open(outputfile,'w')
    fpml.write("hide all\n")
    fpml.write("unset dynamic_measures\n")
    fpml.write("show cartoon, all\n")
    fpml.write("color grey, all\n")
    fpml.write("run draw_links.py\n")
    stat=np.zeros(2)
    for i in range(736):
        for j in range(i+1,736):
            if data[i][j] == 1:
               stat[0] += 1
               if i > 368:
                  i_resid = str(i - 368 + 1)
                  i_chainid = "B"
               else:
                  i_resid = str(i + 1)
                  i_chainid = "A"
               if j > 368:
                  j_resid = str(j - 368 + 1)
                  j_chainid = "B"
               else:      
                  j_resid = str(j + 1)
                  j_chainid = "A"
               atom_i = "CA"
               atom_j = "CA"
               fpml.write("distance max_frst_wm= (///" + i_chainid + "/" + i_resid + "/CA),(///"+j_chainid+"/"+j_resid+"/CA)\n")
               #fpml.write("draw_links resi " + i_resid + " and name " + atom_i + " and Chain " + i_chainid + ", resi " + j_resid +  " and name " + atom_j + " and Chain " + j_chainid + ", color=green, color2=green, radius=0.1, object_name=" + i_resid+":"+j_resid + "_green\n" )
            if data[i][j] == -1:
               stat[1] += 1
               if i > 368:
                  i_resid = str(i - 368 + 1)
                  i_chainid = "B"
               else:      
                  i_resid = str(i + 1)
                  i_chainid = "A"
               if j > 368:
                  j_resid = str(j - 368 + 1)
                  j_chainid = "B"
               else:      
                  j_resid = str(j + 1)
                  j_chainid = "A"
               atom_i = "CA"
               atom_j = "CA"
               fpml.write("distance min_frst_wm= (///" + i_chainid + "/" + i_resid + "/CA),(///"+j_chainid+"/"+j_resid+"/CA)\n")

               #fpml.write("draw_links resi " + i_resid + " and name " + atom_i + " and Chain " + i_chainid + ", resi " + j_resid +  " and name " + atom_j + " and Chain " + j_chainid + ", color=red, color2=red, radius=0.1, object_name=" + i_resid+":"+j_resid + "_red\n" );
    fpml.write("zoom all\n");
    fpml.write("hide labels\n");
    fpml.write("color red, max_frst_wm\n");
    fpml.write("color green, min_frst_wm\n");
    fpml.write("bg_color, white\n");
    fpml.write("color yellow, resid 72-124\n");
    fpml.write("color blue, resid 1-71\n");
    fpml.write("show surface, chain C\n");
    fpml.write("color purple, chain C\n");

    fpml.close()
    print stat

def main():
    #if len(sys.argv) != 6:
    #   print "*py txtfile pdbfile xname yname title"
    #   sys.exit()
    matfile = sys.argv[1]
    pmlfile = sys.argv[2]
    #xname = sys.argv[3]
    convert_frustmap_pml(matfile,pmlfile) 
if __name__ == '__main__':
    main()

