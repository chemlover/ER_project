inpdb=$1
outpdb=$2
python ./mut.py $inpdb x3.pdb LYS ARG 486
python ./mut.py x3.pdb $outpdb LYS ARG 118
