#!/bin/bash
#####This script is to create 19 paralell runs from one run
#zsh
rundir=$1
homedir="/scratch/mc70/ER_COLVAR_noCOA_Sep"
echo "$homedir"
repeat=33
filename="run"
copyname="copy"
#infile="casp.in"
#pbsfile="job.pbs"
#qfile="fix_qbias_coeff.data"
i=$0
echo "hahaha"
j=$0

for ((i=1; i< $repeat; i++));do
        echo "$i"
        let "j=(3*i+2)"
        mkdir $homedir/$filename$i
        cp $homedir/copy/*   $homedir/$filename$i
	#cp $homedir/copy/$infile   $homedir/$filename$i
	#cp $homedir/copy/$pbsfile   $homedir/$filename$i
	cd $homedir/$filename$i 
        #sed "s/create 300\.0 20000/create 300\.0 $RANDOM/"  $infile > temp.in
        #cp temp.in $infile
        sed -i "s/centers           5\.00/centers           ${j}\.00/" proteinDna_bias.colvars
        rm -rf temp**
	sbatch job.pbs
done

