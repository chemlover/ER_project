path = sprintf('/home/xc25/Data_dealing/PU_1_variable/angle_bias/angle_PDB');
%path = '/home/xc25/Data_dealing/PU_1_variable/window_10_6/dist_P'
path = '/home/xc25/Data_dealing/PU_1/update5/design/bias/setup2/test3/'
titlename = 'noCoA_lack_one_hinge'
path =sprintf('/home/xc25/Data_dealing/ER_project/ER_5_old/ER_bias/%s',titlename)
%path = '/home/xc25/Data_dealing/tau_agggregagtion/tau'
%path = '/home/xc25/Data_dealing/tau_R134/tau'
%q_name={  'Bindsite_helix_total','Bending_Angle_bindsite_total' };xname = 'Binding site';yname = 'Bending Angle at Bindsite';
%q_name={  'Bindsite_helix_total','Angle_bound_Helix_DNA_total' };xname = 'Binding site';yname = ' Angle Helix DNA';
%q_name={  'Bindsite_helix_total','p_total' };xname = 'Binding site';yname = ' Debye Huckel energy between protein and DNA';
%q_name={  'Bindsite_helix_total','Bending_Angle_bindsite_local_total' };xname = 'Binding site';yname = 'Bending Angle at Bindsite local';
%q_name={  'Bindsite_helix_total','Angle_bound_Helix_DNA_local_total' };xname = 'Binding site';yname = ' Angle Helix DNA local'
%q_name = {'Bendsite_total','Bendangle_total'};xname = 'Bend site';yname = 'DNA Bending Angle'
%q_name = {'angle','charge'};xname = 'local bending angle';yname = 'charge density surface'
q_name = {'p_total','e_total'};xname = 'Qw';yname = 'energy'
q_name = {'largest_oligomer_total','p_total'};xname = 'largest oligomer size';yname = 'Qw'
q_name = {'first_oligomer_total','inter_para_total'};xname = 'largest oligomer size';yname = 'energy'
q_name = {'largest_oligomer_total','inter_para_total'};xname = 'largest oligomer size';yname = 'inter para hydrogen bond'
q_name = {'49new','distnew'};xname = 'charge density',yname = 'dist between helix and dna'
q_name = {'dist_hinge_average','DBD'};xsym='distance hinge average',ysym='DBD contacts'
q_name = {'DBD','hinge'}
xname = xsym,yname = ysym
%q_name = {'Bindsite_helix_total','p_total'};xname = 'binding site';yname = 'DH energy between protein and dna'
%q_name = {'angle','charge'};xname = 'local bending angle';yname = 'charge density surface'
%q_name = {'angle2_ll','distm_ll'};xname = 'local bending angle';yname = 'dist between helix and dna'
T=300
binN=15;ObinN=16;
prefix=titlename
%'
%
%titlename = 'Landscape of 16 bp'
n_contour=40; % # of contour lines
fsize=40; tsize=20; mr=1; mc=1;
cutoff=6;scrnsize = get(0,'ScreenSize'); 
figure('position', [1 scrnsize(4) 0.25*mc*scrnsize(3) 0.35*scrnsize(4)]);
qa_name=q_name{1}; qb_name=q_name{2};
filename = sprintf('%s/%s',path, qa_name); qa = load(filename);
filename = sprintf('%s/%s',path, qb_name); qb = load(filename);
if strcmp(q_name{1},'dih')
   qa=(mean(qa'))';
end
if strcmp(q_name{2},'dih')
   qb=(mean(qb'))';
end
qa_min=min(qa); qa_max=max(qa);
qb_min=min(qb); qb_max=max(qb);

Nsample=size(qa,1);
%assert(Nsample==size(qb,1));
filename = sprintf('%s/p_total',path); q = load(filename);
filename=sprintf('%s/%s_%d_pmf.dat',path,prefix, T);
FF=load(filename); qx=FF(:,1);  Fy = FF(:,2); nbin=length(qx);
dq=qx(2)-qx(1); qmin=qx(1)-dq/2; qmax= qx(nbin)+dq/2;
Py=exp(-Fy/(0.001987*T)); P_norm = sum(Py); Py=Py/P_norm;
pi_sample = zeros(Nsample,1); ni_sample = zeros(nbin, 1);


for i_bin= 1:nbin
        qi_min = qmin + (i_bin-1)*dq; qi_max= qi_min + dq;
        ids = find( q >= qi_min & q < qi_max ) ;    
        ni_sample(i_bin) = length(ids);        
        if ni_sample(i_bin) > 0
            pi_sample(ids) = Py(i_bin)/ni_sample(i_bin);
        end
end
fprintf('probability = %.3f\n', sum(pi_sample));
        
qa_lin=linspace(min(qa), max(qa),ObinN); qb_lin=linspace(min(qb), max(qb),binN); H=zeros(ObinN,binN);
[~, bin_index_x] = histc(qa, qa_lin); [~, bin_index_y] = histc(qb, qb_lin);
for i_sample = 1:Nsample
    %if q(i_sample) < 140
        x=bin_index_x(i_sample); y=bin_index_y(i_sample);
        H(x,y) = H(x,y) + pi_sample(i_sample);
    %end
end
H=H'; fprintf('sum(sum(H))=%.3f\n', sum(sum(H)));     
F=-0.001987*T*log(H); % ids = (F>= cutoff); F(ids) = -inf;
%subplot(mr,mc,i_label)
[~,h] = contourf(qa_lin, qb_lin,F,n_contour,'edgecolor','none'); %shading flat,
cm = jet 
cm(256,:)=[1 1 1]

colormap(cm); col=colorbar;


ccc = get(h,'children'); max_cdata = -inf; cdata_list=zeros(size(ccc,1), 1);
    
for k=1:size(ccc,1)
        cd1 = get(ccc(k), 'cdata');
        if cd1 > max_cdata
            max_cdata = cd1 ;
        end
        cdata_list(k) = get(ccc(k),'cdata');
end
id = find(cdata_list == max_cdata);
disp(ccc(id));
for k=1:size(id,1)
        set(ccc(id(k)), 'facecolor', 'white');
end

set(gca,'fontsize',fsize/2)
%xlabel(xname, 'fontsize', fsize/2)
%ylabel(yname, 'fontsize', fsize/3)
%xlim([0,100])
xlim([0,120])
ylim([0,120])
%title(titlename,'fontsize',fsize/4)
caxis([1,6])
%caxis([0,20])
saveas(gcf,[path,'/',prefix,'-',xname,'-',yname,'.png'])
