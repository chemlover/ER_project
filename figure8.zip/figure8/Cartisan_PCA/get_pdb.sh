for i in $(seq 1 5);do
    python ../get_pdb_i.py mode$i.pdb PC${i}1.pdb 0 
    python ../get_pdb_i.py mode$i.pdb PC${i}2.pdb 25
    python ../get_pdb_i.py mode$i.pdb PC${i}3.pdb 50
done
