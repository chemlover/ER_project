import os
import sys
import numpy as np
import math
import matplotlib.pyplot as plt
from matplotlib.pyplot import cm as cm
def cutoff_contacts_form(reference,pc,pcnumber):
# get contacts of contactpca of one pc
    pc_get = pc[pcnumber,:]
    #print len(pc_get)
    contactsm = []
    contactsp = []
    cutoffp = []
    cutoffm = []
    #distance = np.min(pc_get)
    for i in range(len(pc_get)):
        cutoff = (reference[i] - 3.0)/ pc_get[i]
        if cutoff >= 0:
           cutoffp.append(cutoff)
        else:
           cutoffm.append(cutoff)
    cutoff1 = np.min(np.array(cutoffp))
    cutoff2 = abs(np.max(np.array(cutoffm)))
    #print cutoff1
    #print cutoff2
    #for i in range(len(pc_get)):
    #    contactp = reference[i]-cutoff1*pc_get[i]#*0.8
    #    contactsp.append(contactp)
    #    contactm = reference[i]-cutoff2*pc_get[i]#*0.8
    #    contactsm.append(contactm)
    #print contactsp
    #print contactsm
    #print len(contactsp),len(contactsm)
    return cutoff1,cutoff2

def reshape_to_matrix(contacts):
# return contactmap format
    length = int(math.sqrt(len(contacts)*2)//1+1)
    distmap = np.zeros((length,length))
    k=0
    x=max(contacts,key=abs)
    print x
    coeff = 100/x
    for i in range(length):
        for j in range(i+1,length):
            #print contacts[k]
            distmap[i][j] = contacts[k]*coeff
            distmap[j][i] = distmap[i][j]
            k = k + 1
    return distmap

def reshape_contact(reference,pc):
    length = int(math.sqrt(len(pc)*2)//1+1)
    cutoffmapp = np.zeros((length,length))
    cutoffmapm = np.zeros((length,length))
    k=0
    contactcutoff = 12
    for i in range(length):
        for j in range(i+1,length):
            #print contacts[k]
            if pc[k] != 0:
               if reference[k] < contactcutoff:
                  #print reference[k],pc[k]
                  if pc[k] > 0 :
                     cutoffmapp[i][j] = -(12-reference[k])/pc[k]
                  else:
                     cutoffmapm[i][j] = (12-reference[k])/pc[k]
               elif reference[k] > contactcutoff:
                  #print reference[k],pc[k]
                  if pc[k] > 0:
                     cutoffmapp[i][j] = (reference[k]-12)/pc[k]
                  else:
                     cutoffmapm[i][j] = -(reference[k]-12)/pc[k]
               cutoffmapp[j][i] = cutoffmapp[i][j]
               cutoffmapm[j][i] = cutoffmapm[i][j]  
               #print cutoffmapp[j][i]
            k = k + 1
    x=999
    for i in range(length):
        for j in range(length):
            if abs(cutoffmapp[i][j]) < x and abs(cutoffmapp[i][j]) > 0:
               x = abs(abs(cutoffmapp[i][j]))
    #print coeffp
    coeffp = 1.0/x
    cutoffmappl=np.zeros((length,length))
    for i in range(length):
        for j in range(length):
           if cutoffmapp[i][j] != 0:
            cutoffmappl[i][j] = x/cutoffmapp[i][j]*100
    x=999
    for i in range(length):
        for j in range(length):
            if abs(cutoffmapm[i][j]) < x and abs(cutoffmapm[i][j]) > 0:
               x = abs(abs(cutoffmapm[i][j]))
    coeffm = 1.0/x
    cutoffmapml=np.zeros((length,length))
    for i in range(length):
        for j in range(length):
           if cutoffmapm[i][j] != 0:
            cutoffmapml[i][j] = x/cutoffmapm[i][j]*100
    return cutoffmappl,cutoffmapml

def convert_contactmap_contacts(cutoffmap):
    p_form=[]
    p_disappear=[]
    [m,n] = np.shape(cutoffmap)
    for i in range(m):
        for j in range(i+3,m):
            if cutoffmap[i][j] > 1.0:
               p_form.append([i,j])
            elif cutoffmap[i][j] < -1.0:
               p_disappear.append([i,j])
    print len(p_form),len(p_disappear)
    return p_form,p_disappear,m
                  
def write_tcl_awsem_model(p_form,p_disappear,n_protein):
# get tcl file for awsem model
    data = ''
    order = 0
    for i in range(len(p_form)):
        ii = int(p_form[i][0])
        jj = int(p_form[i][1])
        if abs(ii - jj) < 4:
           continue
        if ii <= n_protein:
           index_i = ii*5 - 4
        else:
           index_i = n_protein*5 - 4 + (ii - n_protein)*3-5
        if jj <= n_protein:
           index_j = jj*5 - 4
        else:
           index_j = n_protein*5 - 4 + (jj - n_protein)*3-5
        data += "set sel"+str(ii) + " [atomselect top \"serial " + str(index_i) + "\"]\n"
        data += "set sel"+str(jj) + " [atomselect top \"serial " + str(index_j) + "\"]\n"
        data += "lassign [atomselect" + str(order) + " get {x y z}] pos1\n"
        order += 1
        data += "lassign [atomselect" + str(order) + " get {x y z}] pos2\n"
        order += 1
        data += "draw color red\ndraw line $pos1 $pos2 style solid width 2\n"
    for i in range(len(p_disappear)):
        ii = int(p_disappear[i][0])
        jj = int(p_disappear[i][1])
        if ii <= n_protein:
           index_i = ii*5 - 4
        else:
           index_i = n_protein*5 - 4 + (ii - n_protein)*3-5
        if jj <= n_protein:
           index_j = jj*5 - 4
        else:
           index_j = n_protein*5 - 4 + (jj - n_protein)*3-5
        data += "set sel"+str(ii) + " [atomselect top \"serial " + str(index_i) + "\"]\n"
        data += "set sel"+str(jj) + " [atomselect top \"serial " + str(index_j) + "\"]\n"
        data += "lassign [atomselect" + str(order) + " get {x y z}] pos1\n"
        order += 1
        data += "lassign [atomselect" + str(order) + " get {x y z}] pos2\n"
        order += 1
        data += "draw color blue\ndraw line $pos1 $pos2 style solid width 2\n"
    data += "mol addrep 0\nmol modselect 1 0 resid 1 to 71 and chain id A B\nmol modstyle 1 0 newcartoon\nmol modcolor 1 0 colorid 1\n"
    data += "mol addrep 0\nmol modselect 2 0 resid 72 to 124 and chain id A B\nmol modstyle 2 0 newcartoon\nmol modcolor 2 0 colorid 4\n"
    data += "mol addrep 0\nmol modselect 3 0 resid 125 to 368 and chain id A B\nmol modstyle 3 0 newcartoon\nmol modcolor 3 0 colorid 7\n"
    data += "mol addrep 0\nmol modselect 4 0 resid 1 to 11 and chain id C D\nmol modstyle 4 0 newcartoon\nmol modcolor 4 0 colorid 9\n"
    #data += "load traj.psf"
    data += "mol addrep 0\nmol modselect 5 0 resname THY GUA ADE CYT \nmol modstyle 5 0 licorice\nmol modcolor 5 0 colorid 0\n"
    data += "mol delrep 0 0\ncolor Display Background white"
    #data += "mol modselect 0 top all\nmol modstyle 0 top newcartoon\nmol modcolor 0 top colorid 15"
    return data


def main():
    referfile = sys.argv[1]
    pcfile = sys.argv[2]
    pcnumber = int(sys.argv[3])-1
    outputfilename = sys.argv[4]
    reference = np.loadtxt(referfile)
    pc = np.loadtxt(pcfile)
    pc_i = pc[pcnumber,:]
    #pc_matrix = reshape_to_matrix(pc_i)
    cutoffmapp,cutoffmapm = reshape_contact(reference,pc_i)
    p_form,p_disappear,n_protein = convert_contactmap_contacts(cutoffmapp)
    data = write_tcl_awsem_model(p_form,p_disappear,n_protein)
    with open(outputfilename+"+.tcl",'w') as fwrite:
         fwrite.writelines(data)
    p_form,p_disappear,n_protein = convert_contactmap_contacts(cutoffmapm)
    data = write_tcl_awsem_model(p_form,p_disappear,n_protein)
    with open(outputfilename+"-.tcl",'w') as fwrite:
         fwrite.writelines(data)
  
main()                     
