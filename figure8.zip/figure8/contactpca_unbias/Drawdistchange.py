import os
import sys
import numpy as np
import math
import matplotlib.pyplot as plt
from matplotlib.pyplot import cm as cm
def cutoff_contacts_form(reference,pc,pcnumber):
# get contacts of contactpca of one pc
    pc_get = pc[pcnumber,:]
    #print len(pc_get)
    contactsm = []
    contactsp = []
    cutoffp = []
    cutoffm = []
    #distance = np.min(pc_get)
    for i in range(len(pc_get)):
        cutoff = (reference[i] - 3.0)/ pc_get[i]
        if cutoff >= 0:
           cutoffp.append(cutoff)
        else:
           cutoffm.append(cutoff)
    cutoff1 = np.min(np.array(cutoffp))
    cutoff2 = abs(np.max(np.array(cutoffm)))
    #print cutoff1
    #print cutoff2
    #for i in range(len(pc_get)):
    #    contactp = reference[i]-cutoff1*pc_get[i]#*0.8
    #    contactsp.append(contactp)
    #    contactm = reference[i]-cutoff2*pc_get[i]#*0.8
    #    contactsm.append(contactm)
    #print contactsp
    #print contactsm
    #print len(contactsp),len(contactsm)
    return cutoff1,cutoff2

def reshape_to_matrix(contacts):
# return contactmap format
    length = int(math.sqrt(len(contacts)*2)//1+1)
    distmap = np.zeros((length,length))
    k=0
    x=max(contacts,key=abs)
    print x
    coeff = 100/x
    for i in range(length):
        for j in range(i+1,length):
            #print contacts[k]
            distmap[i][j] = contacts[k]*coeff
            distmap[j][i] = distmap[i][j]
            k = k + 1
    return distmap

def draw_contactmap(matrix,title):
    (n_atomsx,n_atomsy) = np.shape(matrix)
    if n_atomsx == n_atomsy:
       n_atoms = n_atomsx
    else:
       print  "matrix is not square"
       sys.exit()
    plt.figure(figsize=(7.5,7.5))
    X=np.arange(1,n_atoms+1);
    cmap = cm.get_cmap('jet')
    Y=np.arange(1,n_atoms+1);
    #ax = plt.pcolor(X,Y,matrix,cmap=cmap)
    x=np.max(np.absolute(matrix))
    print x
    ax = plt.pcolormesh(matrix,vmin = -x, vmax = x,cmap='RdBu_r')
    #,edgecolors='k')
#colorbar;
    plt.colorbar()
    #cmax = max(matrix)
    #plt.clim(0,1)
    major_ticks = np.arange(1, n_atoms+1,8)
    minor_ticks = np.arange(1, n_atoms+1,8)
    ax = plt.axes()
    #ax.set_xticks(major_ticks)
    #ax.set_xticks(minor_ticks, minor=True)
    #ax.set_yticks(major_ticks)
    #ax.set_yticks(minor_ticks, minor=True)
#plt.grid()
    ax.set_yticks([72,124,368,441,491,736], minor=False)
    ax.set_yticks([72,124,368,441,491,736], minor=True)
    ax.yaxis.grid(True, which='major')
    ax.yaxis.grid(True, which='minor')
    ax.set_xticks([72,124,368,441,491,736], minor=False)
    ax.set_xticks([72,124,368,441,491,736], minor=True)
    ax.xaxis.grid(True, which='major')
    ax.xaxis.grid(True, which='minor')
    #plt.axis([0,n_atoms+1, 0, n_atoms+1])
    plt.xticks(fontsize=5)
    plt.yticks(fontsize=20)
    plt.gca().set_aspect('equal', adjustable='box')
    plt.gca().set_xticks([])
    plt.savefig('%s.png'%(title),dpi=600)

def main():
    pcfile = sys.argv[1]
    pcnumber = int(sys.argv[2])-1
    outputfilename = sys.argv[3]
    pc = np.loadtxt(pcfile)
    pc_i = pc[pcnumber,:]
    pc_matrix = reshape_to_matrix(pc_i)
    draw_contactmap(pc_matrix,outputfilename)

main()                     
