import os
import sys
import numpy as np
import math
import matplotlib.pyplot as plt
from matplotlib.pyplot import cm as cm
def cutoff_contacts_form(reference,pc,pcnumber,cutoff):
# get contacts of contactpca of one pc
    pc_get = pc[pcnumber,:]
    #print len(pc_get)
    contactsm = []
    contactsp = []
    cutoffp = []
    cutoffm = []
    #distance = np.min(pc_get)
    #for i in range(len(pc_get)):
    contactcutoff =  12.0
    n_contactsp = 0
    n_contactsm = 0
    for i in range(len(reference)):
        if reference[i] > contactcutoff and reference[i] +  cutoff * pc_get[i] < contactcutoff:
           n_contactsp += 1
        elif reference[i] < contactcutoff and reference[i] +  cutoff * pc_get[i] > contactcutoff:
           n_contactsm += 1 
    print "positive orientation"
    print n_contactsp,n_contactsm
    n_contactsp = 0
    n_contactsm = 0
    for i in range(len(reference)):
        if reference[i] > contactcutoff and reference[i] -  cutoff * pc_get[i] < contactcutoff:
           n_contactsp += 1
        elif reference[i] < contactcutoff and reference[i] -  cutoff * pc_get[i] > contactcutoff:
           n_contactsm += 1
    print "negative orientation"
    print n_contactsp,n_contactsm
    print "output"

def trasnform_matrix(contacts):
    length = int(math.sqrt(len(contacts)*2)//1+1)
    distmap = np.zeros((length,length))
    k=0
    for i in range(length):
        for j in range(i+1,length):
            distmap[i][j] = contacts[k]
            distmap[j][i] = distmap[i][j]
            k = k + 1
    return distmap

def reshape_to_matrix(reference,pc,pcnumber,cutoff):
# return contactmap format
    pc_get = pc[pcnumber,:]
    length = int(math.sqrt(len(pc_get)*2)//1+1)
    contactmapp = np.zeros((length,length))
    contactmapm = np.zeros((length,length))
    k=0
    print cutoff 
    referm = trasnform_matrix(reference)
    pcm = trasnform_matrix(pc_get)
    for i in range(length):
        for j in range(i+1,length):
            distp =  referm[i][j] +  cutoff * pcm[i][j]
    #        print referm[i][j],distp
            if referm[i][j] > 12 and distp < 12:
               contactmapp[i][j] = 1
               contactmapp[j][i] = contactmapp[i][j]
               #print referm[i][j],distp
            elif referm[i][j] < 12 and distp > 12:
               contactmapp[i][j] = -1
               contactmapp[j][i] = contactmapp[i][j]
            distm =  referm[i][j] -  cutoff * pcm[i][j]
            if referm[i][j] > 12 and distm < 12:
               contactmapm[i][j] = 1
               contactmapm[j][i] = contactmapm[i][j]
            elif referm[i][j] < 12 and distm > 12:
               contactmapm[i][j] = -1
               contactmapm[j][i] = contactmapm[i][j]
            k = k + 1
    return contactmapp,contactmapm

def draw_contactmap(matrix,title,n_bins):
    (n_atomsx,n_atomsy) = np.shape(matrix)
    if n_atomsx == n_atomsy:
       n_atoms = n_atomsx
    else:
       print  "matrix is not square"
       sys.exit()
    plt.figure(figsize=(7.5,7.5))
    n_protein = n_atoms
    cmap = cm.get_cmap('jet')
    num = n_protein//n_bins + 1
    n_fake = num*n_bins
    X=np.arange(1,n_protein+1,num);
    cmap = cm.get_cmap('jet')
    #cmap = cm.get_cmap('RdBu_r')
    Y=np.arange(1,n_protein+1,num);
    #ax = plt.pcolor(X,Y,matrix,cmap=cmap)
    #x=np.max(np.absolute(matrix))
    #print x
    #ax = plt.pcolormesh(matrix,vmin = -1, vmax = 1,cmap='RdBu_r')
    #,edgecolors='k')
#colorbar;
    full_matrix = np.zeros((n_fake,n_fake))
    for i in range(n_protein):
        for j in range(n_protein):
            full_matrix[i][j] = matrix[i][j]
    xlist,ylist = np.meshgrid(X, Y)
    bin_matrix = np.zeros((n_bins,n_bins))
    for i in range(n_bins):
        for j in range(n_bins):
            i_begin = i*num
            j_begin = j*num
            for l in range(i_begin,i_begin+num):
                for n in range(j_begin,j_begin+num):
                    bin_matrix[i][j] += float(full_matrix[l][n])/num/num
    #cs=plt.contourf(xlist, ylist,bin_matrix,cmap=cmap)#,extend="both")
    #cs.set_clim(-1,1)
    #x=np.max([np.max(bin_matrix),abs(np.min(bin_matrix))])
    #print x
    for i in range(n_bins):
        for j in range(n_bins):
             if abs(bin_matrix[i][j] - 0) < 0.05:
                if bin_matrix[i][j] < 0:
                   bin_matrix[i][j] = -1.1
                elif bin_matrix[i][j] > 0:
                   bin_matrix[i][j] = 1.1
                #bin_matrix[j][i] = 1.1
    #            print i,j
    #bin_matrix[0][0] = -1.1
    #bin_matrix[-1][-1] = -1.1
    cs=plt.contourf(xlist, ylist,bin_matrix,vmin=-1,vmax=1,cmap=plt.cm.jet,extend="both")
    cs.cmap.set_under('w')
    cs.cmap.set_over("w")
    plt.colorbar()
    major_ticks = np.arange(1, n_atoms+1,8)
    minor_ticks = np.arange(1, n_atoms+1,8)
    ax = plt.axes()
    #ax.set_xticks(major_ticks)
    #ax.set_xticks(minor_ticks, minor=True)
    #ax.set_yticks(major_ticks)
    #ax.set_yticks(minor_ticks, minor=True)
#plt.grid()
    ax.set_yticks([72,124,368,441,491,736], minor=False)
    ax.set_yticks([72,124,368,441,491,736], minor=True)
    ax.yaxis.grid(True, which='major')
    ax.yaxis.grid(True, which='minor')
    ax.set_xticks([72,124,368,441,491,736], minor=False)
    ax.set_xticks([72,124,368,441,491,736], minor=True)
    ax.xaxis.grid(True, which='major')
    ax.xaxis.grid(True, which='minor')
    #plt.axis([0,n_atoms+1, 0, n_atoms+1])
    plt.xticks(fontsize=5)
    plt.yticks(fontsize=20)
    plt.gca().set_aspect('equal', adjustable='box')
    plt.gca().set_xticks([])
    plt.savefig('%s.png'%(title))#,dpi=600)

def main():
    referfile = sys.argv[1]
    pcfile = sys.argv[2]
    pcnumber = int(sys.argv[3])-1
    outputfilename = sys.argv[4]
    cutoff = float(sys.argv[5])
    nbins = int(sys.argv[6])
    reference = np.loadtxt(referfile)
    pc = np.loadtxt(pcfile)
    pc_i = pc[pcnumber,:]
    cutoff_contacts_form(reference,pc,pcnumber,cutoff)
    contactmapp,contactmapm = reshape_to_matrix(reference,pc,pcnumber,cutoff)
    draw_contactmap(contactmapp,outputfilename+"positive",nbins)
    draw_contactmap(contactmapm,outputfilename+"negative",nbins)


main()                     
