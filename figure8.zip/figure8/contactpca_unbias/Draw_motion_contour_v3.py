import os
import sys
import numpy as np 
import math 
import matplotlib.pyplot as plt
from matplotlib.pyplot import cm as cm

def pc_contacts_matrix(reference,pc,pcnumber):
# get contacts of contactpca of one pc
    pc_get = pc[pcnumber,:]
    #print len(pc_get)
    contactsm = []
    contactsp = []
    cutoffp = []
    cutoffm = []
    #distance = np.min(pc_get)
    for i in range(len(pc_get)):
        cutoff = (reference[i] - 3.0)/ pc_get[i]
        if cutoff >= 0:
           cutoffp.append(cutoff)  
        else:
           cutoffm.append(cutoff)
    cutoff1 = np.min(np.array(cutoffp))
    cutoff2 = abs(np.max(np.array(cutoffm)))
    #print cutoff1
    #print cutoff2
    for i in range(len(pc_get)):
        contactp = reference[i]-cutoff1*pc_get[i]#*0.8
        contactsp.append(contactp)
        contactm = reference[i]-cutoff2*pc_get[i]#*0.8
        contactsm.append(contactm)
    #print contactsp
    #print contactsm
    #print len(contactsp),len(contactsm)
    return contactsp,contactsm

def reshape_contacts(contacts):
# return contactmap format
    length = int(math.sqrt(len(contacts)*2)//1+1)
    distmap = np.zeros((length,length))
    contactmap = np.zeros((length,length))
    k=0
    for i in range(length):
        for j in range(i+1,length):
            #print contacts[k]
            distmap[i][j] = contacts[k]
            distmap[j][i] = distmap[i][j]
            k = k + 1 
    return distmap

def get_contactmap_from_distmap(distmap,cutoff):
# return contact information from distance
    [m,n] = np.shape(distmap)
    contactmap = np.zeros((m,m))
    for i in range(m):
         for j in range(i+3,m):            
           if  distmap[i][j] <= cutoff:
               contactmap[i][j] = 1
               contactmap[j][i] = contactmap[i][j]
    return contactmap

def get_contacts_change(contactmap_refer,contactmapp,contactmapm):
# get one motion and one orientation
    p_form = []
    p_disappear = []
    m_form = []
    m_disappear = []
    length = len(contactmap_refer)
    for i in range(length):
        for j in range(i+4,length):
               pair = [i+1,j+1]
               #print i,j
            #if contactmap_refer[i][j] == 0.0:
               if contactmapp[i][j] == 1.0:
                  p_form.append(pair)
                  #print pair
               if contactmapm[i][j] == 1.0:
                  m_form.append(pair)
            #else:
               if contactmapp[i][j] == 0.0:
                  p_disappear.append(pair)
               if contactmapm[i][j] == 0.0:
                  m_disappear.append(pair)
    return np.array(p_form),np.array(p_disappear),np.array(m_form),np.array(m_disappear)

def merge_contact_change(p_form,pc_i):
    pc_im = reshape_contacts(pc_i)
    matrix = np.zeros((len(p_form),3))
    for i in range(len(p_form)):
        x = int(p_form[i][0]) - 1
        y = int(p_form[i][1]) - 1
        matrix[i][0] = p_form[i][0]
        matrix[i][1] = p_form[i][1]
        matrix[i][2] = pc_im[x][y]
    return matrix

def get_number_contacts(contactpcs,number):
    sortcontactpcs = contactpcs[contactpcs[:,2].argsort()]
    length = np.min([np.shape(sortcontactpcs)[0],number]) 
    p_largest = []
    p_smallest = []
    #print sortcontactpcs
    for i in range(length):
        if sortcontactpcs[-i][2] >= 0:
        #   print sortcontactpcs
           i_x = int(sortcontactpcs[-i][0])
           i_y = int(sortcontactpcs[-i][1])
           pair = [i_x,i_y]
           #if abs(i_x - i_y) > 3:
           p_largest.append(pair)
        if sortcontactpcs[i][2] <= 0:
           i_x = int(sortcontactpcs[i][0])
           i_y = int(sortcontactpcs[i][1])
           pair = [i_x,i_y]
           #if abs(i_x - i_y) > 3:
           p_smallest.append(pair)
    return p_largest,p_smallest

def remap_change_pc(pc_i):
    n_protein = int(math.sqrt(len(pc_i)*2))//1 + 1
    k = 0
    map_connection = np.zeros((len(pc_i),3))
    for i in range(n_protein):
        for j in range(i+1,n_protein):
            #print weight
            weight = float(pc_i[k])
            #print weight
            #pair = [i+1,j+1,weight]
            map_connection[k][0] = i + 1
            map_connection[k][1] = j + 1
            map_connection[k][2] = weight
            k += 1
    return map_connection

def get_number_contacts_absolute(contactpcs,number):
    [m,n] = np.shape(contactpcs)
    affilate = np.zeros((m,n+1))
    for i in range(m):
        for j in range(n):
            affilate[i][j] = contactpcs[i][j]
        affilate[i][n] = abs(contactpcs[i][n-1])
    sortcontactpcs = affilate[affilate[:,n].argsort()]
    contacts_p = []
    contacts_m = []
    length = np.min([m,number])
    p_absolute = []
    print sortcontactpcs
    for i in range(length):
        if sortcontactpcs[-i][n-1] > 0:
           i_x = int(sortcontactpcs[-i][0])
           i_y = int(sortcontactpcs[-i][1])
           pair = [i_x,i_y]
           if abs(i_x - i_y) > 3:
              contacts_p.append(pair)
        if sortcontactpcs[-i][n-1] <= 0:
           i_x = int(sortcontactpcs[-i][0])
           i_y = int(sortcontactpcs[-i][1])
           pair = [i_x,i_y]
           if abs(i_x - i_y) > 3:
              contacts_m.append(pair)
        p_absolute.append(pair)
    if len(contacts_p) >= len(contacts_m):
       p_form = contacts_p
       p_disappear = contacts_m
    else:
       p_form = contacts_m
       p_disappear = contacts_p
    print p_form
    print p_disappear
    return p_form,p_disappear,p_absolute

def get_matrix_pair(n_protein,p_absolute):
    contactmap = np.zeros((n_protein,n_protein))
    for i in range(len(p_absolute)):
        index_i = int(p_absolute[i][0])-1
        index_j = int(p_absolute[i][1])-1
        contactmap[index_i][index_j] = 1
        contactmap[index_j][index_i] = contactmap[index_i][index_j] 
    return contactmap

def write_tcl_awsem_model(p_form,p_disappear,n_protein):
# get tcl file for awsem model
    data = ''
    order = 0
    for i in range(len(p_form)):
        ii = int(p_form[i][0])
        jj = int(p_form[i][1])
        if abs(ii - jj) < 4:
           continue
        if ii <= n_protein:
           index_i = ii*5 - 4
        else:
           index_i = n_protein*5 - 4 + (ii - n_protein)*3-5
        if jj <= n_protein:
           index_j = jj*5 - 4 
        else:
           index_j = n_protein*5 - 4 + (jj - n_protein)*3-5
        data += "set sel"+str(ii) + " [atomselect top \"serial " + str(index_i) + "\"]\n"
        data += "set sel"+str(jj) + " [atomselect top \"serial " + str(index_j) + "\"]\n"
        data += "lassign [atomselect" + str(order) + " get {x y z}] pos1\n"
        order += 1
        data += "lassign [atomselect" + str(order) + " get {x y z}] pos2\n"
        order += 1
        data += "draw color red\ndraw line $pos1 $pos2 style solid width 2\n"
    for i in range(len(p_disappear)):
        ii = int(p_disappear[i][0])
        jj = int(p_disappear[i][1])
        if ii <= n_protein:
           index_i = ii*5 - 4
        else:
           index_i = n_protein*5 - 4 + (ii - n_protein)*3-5
        if jj <= n_protein:
           index_j = jj*5 - 4   
        else:
           index_j = n_protein*5 - 4 + (jj - n_protein)*3-5
        data += "set sel"+str(ii) + " [atomselect top \"serial " + str(index_i) + "\"]\n"
        data += "set sel"+str(jj) + " [atomselect top \"serial " + str(index_j) + "\"]\n"
        data += "lassign [atomselect" + str(order) + " get {x y z}] pos1\n"
        order += 1
        data += "lassign [atomselect" + str(order) + " get {x y z}] pos2\n"
        order += 1
        data += "draw color blue\ndraw line $pos1 $pos2 style solid width 2\n"
    data += "mol addrep 0\nmol modselect 1 0 resid 1 to 71 and chain id A B\nmol modstyle 1 0 newcartoon\nmol modcolor 1 0 colorid 8\n"
    data += "mol addrep 0\nmol modselect 2 0 resid 72 to 124 and chain id A B\nmol modstyle 2 0 newcartoon\nmol modcolor 2 0 colorid 4\n"
    data += "mol addrep 0\nmol modselect 3 0 resid 125 to 368 and chain id A B\nmol modstyle 3 0 newcartoon\nmol modcolor 3 0 colorid 7\n"
    data += "mol addrep 0\nmol modselect 4 0 resid 1 to 11 and chain id C D\nmol modstyle 4 0 newcartoon\nmol modcolor 4 0 colorid 9\n"
    #data += "load traj.psf"
    data += "mol addrep 0\nmol modselect 5 0 resname THY GUA ADE CYT \nmol modstyle 5 0 licorice\nmol modcolor 5 0 colorid 0\n"
    data += "mol delrep 0 0\ncolor Display Background white"
    #data += "mol modselect 0 top all\nmol modstyle 0 top newcartoon\nmol modcolor 0 top colorid 15"
    return data

def write_tcl_awsem_model_two_part(p_form,p_disappear,n_protein):
# get tcl file for awsem model
    data = ''
    order = 0
    for i in range(len(p_form)):
        ii = int(p_form[i][0])
        jj = int(p_form[i][1])
        if abs(ii - jj) < 4:
           continue
        if ii <= n_protein:
           index_i = ii*5 - 4
        else:
           index_i = n_protein*5 - 4 + (ii - n_protein)*3-5
        if jj <= n_protein:
           index_j = jj*5 - 4
        else:
           index_j = n_protein*5 - 4 + (jj - n_protein)*3-5
        data += "set sel"+str(ii) + " [atomselect top \"serial " + str(index_i) + "\"]\n"
        data += "set sel"+str(jj) + " [atomselect top \"serial " + str(index_j) + "\"]\n"
        data += "lassign [atomselect" + str(order) + " get {x y z}] pos1\n"
        order += 1
        data += "lassign [atomselect" + str(order) + " get {x y z}] pos2\n"
        order += 1
        data += "draw color red\ndraw line $pos1 $pos2 style solid width 2\n"
    data += "mol addrep 0\nmol modselect 1 0 resid 1 to 71 and chain id A B\nmol modstyle 1 0 newcartoon\nmol modcolor 8 0 colorid 8\n"
    data += "mol addrep 0\nmol modselect 2 0 resid 72 to 124 and chain id A B\nmol modstyle 2 0 newcartoon\nmol modcolor 2 0 colorid 4\n"
    data += "mol addrep 0\nmol modselect 3 0 resid 125 to 368 and chain id A B\nmol modstyle 3 0 newcartoon\nmol modcolor 3 0 colorid 7\n"
    data += "mol addrep 0\nmol modselect 4 0 resid 1 to 11 and chain id C D\nmol modstyle 4 0 newcartoon\nmol modcolor 4 0 colorid 9\n"
    #data += "load traj.psf"
    #data += "mol addrep 0\nmol modselect 5 0 resname THY GUA ADE CYT \nmol modstyle 5 0 licorice\nmol modcolor 16 0 colorid 0\n"
    data += "mol delrep 0 0\ncolor Display Background white"
    #data += "mol modselect 0 top all\nmol modstyle 0 top newcartoon\nmol modcolor 0 top colorid 15"
    data_formed = data
    data = ''
    order = 0
    for i in range(len(p_disappear)):
        ii = int(p_disappear[i][0])
        jj = int(p_disappear[i][1])
        if ii <= n_protein:
           index_i = ii*5 - 4
        else:
           index_i = n_protein*5 - 4 + (ii - n_protein)*3-5
        if jj <= n_protein:
           index_j = jj*5 - 4
        else:
           index_j = n_protein*5 - 4 + (jj - n_protein)*3-5
        data += "set sel"+str(ii) + " [atomselect top \"serial " + str(index_i) + "\"]\n"
        data += "set sel"+str(jj) + " [atomselect top \"serial " + str(index_j) + "\"]\n"
        data += "lassign [atomselect" + str(order) + " get {x y z}] pos1\n"
        order += 1
        data += "lassign [atomselect" + str(order) + " get {x y z}] pos2\n"
        order += 1
        data += "draw color blue\ndraw line $pos1 $pos2 style solid width 2\n"
    data += "mol addrep 0\nmol modselect 1 0 resid 1 to 71 and chain id A B\nmol modstyle 1 0 newcartoon\nmol modcolor 8 0 colorid 1\n"
    data += "mol addrep 0\nmol modselect 2 0 resid 72 to 124 and chain id A B\nmol modstyle 2 0 newcartoon\nmol modcolor 2 0 colorid 4\n"
    data += "mol addrep 0\nmol modselect 3 0 resid 125 to 368 and chain id A B\nmol modstyle 3 0 newcartoon\nmol modcolor 3 0 colorid 7\n"
    data += "mol addrep 0\nmol modselect 4 0 resid 1 to 11 and chain id C D\nmol modstyle 4 0 newcartoon\nmol modcolor 4 0 colorid 9\n"
    #data += "load traj.psf"
    #data += "mol addrep 0\nmol modselect 5 0 resname THY GUA ADE CYT \nmol modstyle 5 0 licorice\nmol modcolor 5 0 colorid 16\n"
    data += "mol delrep 0 0\ncolor Display Background white"
    #data += "mol modselect 0 top all\nmol modstyle 0 top newcartoon\nmol modcolor 0 top colorid 15"
    data_disappeared = data
    return data_formed,data_disappeared
    
def Draw_contactmap_formdisappear(n_protein,p_form,p_disappear,title):
    #plt.figure(figsize=(100,100))
    X=np.arange(1,n_protein+1);
    cmap = cm.get_cmap('jet')
    Y=np.arange(1,n_protein+1);
    xname = "residue"
    yname = "residue"
    plt.xlabel(xname,fontsize=30)
    plt.ylabel(yname,fontsize=30)
    plt.title(title,fontsize=10)
    major_ticks = np.arange(1, n_protein+1,8)
    minor_ticks = np.arange(1, n_protein+1,8)
    ax = plt.axes()
    ax.set_yticks([72,124,368,439,491,736], minor=False)
    ax.set_yticks([72,124,368,439,491,736], minor=True)
    ax.yaxis.grid(True, which='major')
    ax.yaxis.grid(True, which='minor')
    ax.set_xticks([72,124,368,439,491,736], minor=False)
    ax.set_xticks([72,124,368,439,491,736], minor=True)
    ax.xaxis.grid(True, which='major')
    ax.xaxis.grid(True, which='minor')
    #plt.axis([0,n_atoms+1, 0, n_atoms+1])
    plt.xticks(fontsize=5)
    plt.yticks(fontsize=20)
    plt.gca().set_aspect('equal', adjustable='box')
    for i in range(len(p_form)):
        index_i = int(np.max(p_form[i]))
        index_j = int(np.min(p_form[i]))
        plt.plot([index_i],[index_j],'rs')
    for i in range(len(p_disappear)):
        index_i = int(np.min(p_disappear[i]))
        index_j = int(np.max(p_disappear[i]))
        plt.plot([index_i],[index_j],'bs') 
    #plt.show()
    plt.xlim(1,n_protein)
    plt.ylim(1,n_protein)
    picturename = title + ".png"
    plt.savefig(picturename)           

def Draw_contour(n_protein,pc_matrix,title,n_bins):
    #plt.figure(figsize=(100,100))
    num = n_protein//n_bins + 1
    n_fake = num*n_bins
    X=np.arange(1,n_protein+1,num);
    cmap = cm.get_cmap('jet')
    Y=np.arange(1,n_protein+1,num);
    xname = "residue"
    yname = "residue"
    plt.xlabel(xname,fontsize=30)
    plt.ylabel(yname,fontsize=30)
    plt.title(title,fontsize=30)
    full_matrix = np.zeros((n_fake,n_fake))
    for i in range(n_protein):
        for j in range(n_protein):
            full_matrix[i][j] = pc_matrix[i][j]
    major_ticks = np.arange(1, n_protein+1,8)
    minor_ticks = np.arange(1, n_protein+1,8)
    ax = plt.axes()
    ax.set_yticks([72,124,368,439,491,736], minor=False)
    ax.set_yticks([72,124,368,439,491,736], minor=True)
    ax.yaxis.grid(True, which='major')
    ax.yaxis.grid(True, which='minor')
    ax.set_xticks([72,124,368,439,491,736], minor=False)
    ax.set_xticks([72,124,368,439,491,736], minor=True)
    ax.xaxis.grid(True, which='major')
    ax.xaxis.grid(True, which='minor')
    #plt.axis([0,n_atoms+1, 0, n_atoms+1])
    plt.xticks(fontsize=5)
    plt.yticks(fontsize=20)
    plt.gca().set_aspect('equal', adjustable='box')
    xlist,ylist = np.meshgrid(X, Y)
    bin_matrix = np.zeros((n_bins,n_bins))
    for i in range(n_bins):
        for j in range(n_bins):
            i_begin = i*num
            j_begin = j*num
            for l in range(i_begin,i_begin+num):
                for n in range(j_begin,j_begin+num):
                    bin_matrix[i][j] += float(full_matrix[l][n])/num/num
    x=np.max([np.max(bin_matrix),abs(np.min(bin_matrix))])
    print x
    for i in range(n_bins):
        for j in range(n_bins):
             if bin_matrix[i][j] == 0:
                bin_matrix[i][j] = -x
                bin_matrix[j][i] = -x
                print i,j
    cs=plt.contourf(xlist, ylist,bin_matrix,cmap=plt.cm.jet,extend="both")
    cs.cmap.set_under('w')
    plt.xlim(1,n_protein)
    plt.ylim(1,n_protein)
    picturename = title + ".png"
    plt.colorbar(cs)
    plt.savefig(picturename)


def main():
    #referencefile = sys.argv[1]
    pcfile = sys.argv[1]
    pcnumber = int(sys.argv[2])-1
    outputfilename = sys.argv[3]
    n_protein = int(sys.argv[4])
    n_contacts = int(sys.argv[5])
    n_bins = int(sys.argv[6])
    #reference = np.loadtxt(referencefile)
    pc = np.loadtxt(pcfile)
    pc_i = pc[pcnumber,:]
    cutoff = 10
    #pc_matrix = reshape_contacts(pc_i)
    contactpcs = remap_change_pc(pc_i)
    #print contactpcs
    p_form,p_disappear,p_absolute = get_number_contacts_absolute(contactpcs,n_contacts)
    pc_matrix = get_matrix_pair(n_protein,p_absolute)
    title = outputfilename 
    Draw_contour(n_protein,pc_matrix,title,n_bins)
    #Draw_contactmap_formdisappear(n_protein,p_form,p_disappear,title)
    #title = outputfilename + "-"
    #Draw_contactmap_formdisappear(n_protein,p_disappear,p_form,title)

if __name__ == '__main__':
    main()

