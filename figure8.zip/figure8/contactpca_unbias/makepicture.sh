rm *png
rm *tcl
python ../../../figure2/draw_bar.py contact_dist.txt
for i in $(seq 1 5);do
    python ../Drawdistchange.py contact_pc.txt $i PC${i}dist
    python ../Drawcontactchange_cutoff.py contact_reference.txt contact_pc.txt $i PC${i}contact    
    python ../WriteTcl_contactpca.py contact_reference.txt contact_pc.txt $i PC${i}
done
