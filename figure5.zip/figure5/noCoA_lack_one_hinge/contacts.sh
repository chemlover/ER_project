awk '{print $1}' contacts_total > DBD
awk '{print $2}' contacts_total > hinge
awk '{print $3}' contacts_total > LBD
