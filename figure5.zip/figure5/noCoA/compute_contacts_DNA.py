import os
from math import *
import sys
def get_cbeta_dump(dump_lines):
        cb_atoms_dump = []; box = []; A = []
        for l in dump_lines:
                l = l.strip()
                if l[:5]=="ITEM:": item = l[6:]
                elif item[:10] == "BOX BOUNDS":
                    box.append(l)
                    l = l.split()
                    A.append([float(l[0]), float(l[1])])
                elif item[:5] == "ATOMS":
                        l = l.split()  ; i_atom = l[0]
                        x = float(l[2]); y = float(l[3]); z = float(l[4])
                        x = (A[0][1] - A[0][0])*x + A[0][0]
                        y = (A[1][1] - A[1][0])*y + A[1][0]
                        z = (A[2][1] - A[2][0])*z + A[2][0]
                        if int(l[1]) == 18 or int(l[1]) == 19 or int(l[1]) == 2: 
                                atom_CA = [x,y,z]
                                cb_atoms_dump.append(atom_CA)
        return cb_atoms_dump

def vector(p1, p2):
    return [p2[0]-p1[0], p2[1]-p1[1], p2[2]-p1[2]]

def vabs(a):
    return sqrt(pow(a[0],2)+pow(a[1],2)+pow(a[2],2))

def get_contacts_group(cb_atoms,index_group1,index_group2,cutoff):
    n_contacts = 0
    for i in index_group1:
        for j in index_group2:
            #print i,j,len(cb_atoms)
            if vabs(vector(cb_atoms[i],cb_atoms[j])) <= cutoff:
               n_contacts += 1
    return n_contacts

def get_file_len(filename):
    exeline="wc -l "+filename ;
    stdout=os.popen(exeline).readline();
    stdout=stdout.split()
    return int(stdout[0])

def getline_range(filename, line1, line2):
    assert(line1 <= line2)
    nline=line2-line1+1
    exeline="head -n"+str(line2)+" "+filename+" | tail -n"+str(nline) ;
    #print exeline
    stdout=os.popen(exeline).readlines()
    return stdout
def get_natoms(dump_file):
        line=getline_range(dump_file, 4,4); line=line[0].split()
        natoms=int(line[0])
        return natoms
def get_nline_snapshot(dump_file):
        natoms=get_natoms(dump_file)
        nline=natoms + 9
        return nline

def get_dump_i(dump_file, i):
        nline=get_nline_snapshot(dump_file)
        line_start = 1 + nline*i ; line_end = nline*(i+1)
        dump_part=getline_range(dump_file, line_start, line_end)
        return dump_part

def get_contacts_traj(trajfile,index_group1,index_group2,index_group3,index_group4,cutoff):
    file_len=get_file_len(trajfile)
    line = getline_range(trajfile, 4, 4); line=line[0].split() ; #get number of atoms
    n_atoms=int(line[0]) ; nline=n_atoms + 9
    n_snapshot=file_len / nline
    out = open("contacts_total", 'w')
    for i in range(n_snapshot):
        line_start = 1 + nline*i ; line_end = nline*(i+1)
        dump_part=getline_range(trajfile, line_start, line_end)
        cb_atoms= get_cbeta_dump(dump_part)
        n_contacts1 = get_contacts_group(cb_atoms,index_group1,index_group4,cutoff)
        n_contacts2 = get_contacts_group(cb_atoms,index_group2,index_group4,cutoff)
        n_contacts3 = get_contacts_group(cb_atoms,index_group3,index_group4,cutoff)
        print n_contacts3
        out.write(str(n_contacts1)+' '+str(n_contacts2)+ " " + str(n_contacts3)+ "\n")
    out.close()

def main():
    trajfile = sys.argv[1]
    hingegroup = [] 
    DBDgroup = []
    DNAgroup = []
    LBDgroup = []
    for i in range(71,123):
        hingegroup.append(i)
    for i in range(439,491):
        hingegroup.append(i)
    for i in range(0,71):
        DBDgroup.append(i)
    for i in range(368,439):
        DBDgroup.append(i)    
    for i in range(736,772):
        DNAgroup.append(i)
    for i in range(124,368):
        LBDgroup.append(i)
    for i in range(492,736):
        LBDgroup.append(i)
    cutoff = 10
    get_contacts_traj(trajfile,DBDgroup,hingegroup,LBDgroup,DNAgroup,cutoff)

if __name__ == '__main__':
    main()


    
