import os
import sys
import numpy as np
inputfile = sys.argv[1]
outputfile = sys.argv[2]
resno = sys.argv[3]
resnn = sys.argv[4]
resido = int(sys.argv[5])
data = ""
with open(inputfile,"r") as fopen:
     for line in fopen.readlines():
         if len(line)>18:
            resname = line[17:20]
            resid = int(line[23:26])
            if resname = resno and resido == resid:
               data += line[0:17] + resnn + line[20:81]
               print ("do")
            else:
               data += line
with open(outputfile,"w") as fwrite:
     fwrite.writelines(data)

